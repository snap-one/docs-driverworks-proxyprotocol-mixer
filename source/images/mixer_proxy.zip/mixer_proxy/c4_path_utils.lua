function GetAudioProviderOutputIdRoomIMap()
	local thisProxyId = tonumber(GetProxyID(MAIN_PROXY_BINDING_ID)) or 0

	local tOutputRoomIdMap = {}
	for roomId, roomName in pairs(RoomIDs) do
		-- ************************************************************* --
		-- get Audio End-Point for requested room
		local audioEndPointDeviceProxyID = GetRoomEndPointDeviceProxyID(roomId, ROOM_CONN_ID_MAP["Audio End-Point 1"])
		if audioEndPointDeviceProxyID ~= nil then
			if tonumber(audioEndPointDeviceProxyID) == thisProxyId then
				for roomBindingConnId = 7000, 7999 do
					local idConsumer, nameConsumer = GetBoundConsumerDevice(thisProxyId, roomBindingConnId)
					if idConsumer then
						--print(idConsumer, nameConsumer)
						if idConsumer == roomId then
							tOutputRoomIdMap[roomBindingConnId] = roomId
						end
					end
				end
			else
				-- walk path back to determine audio output ID and return it
				local function func(_providerDeviceProxyId)
					--print('>>>>>', _providerDeviceProxyId)
					if _providerDeviceProxyId == 0 or _providerDeviceProxyId == nil then return end
					local providerDeviceProxyId = 0
					for consumerConnId = 3000, 3999 do
						providerDeviceProxyId = C4:GetBoundProviderDevice(_providerDeviceProxyId, consumerConnId)
						if tonumber(providerDeviceProxyId) == 0 then
							providerDeviceProxyId = GetNonbindingProviderDevice(providerDeviceProxyId, consumerConnId)
						end

						-- if the provider is our mixer then we need to find the output that connects to this consumer....
						if tonumber(providerDeviceProxyId) == thisProxyId then
							for providerOutputConnId = 4000, 4000+NUM_ZONES-1 do
								local consumerProxyId, consumerInputConnId = C4:GetBoundPartner(providerDeviceProxyId, providerOutputConnId, "STEREO")
								if consumerInputConnId then
									local thisRoomId, nameRoom = GetBoundConsumerDevice(_providerDeviceProxyId, 7000+consumerInputConnId%1000)
									if (consumerProxyId == tonumber(_providerDeviceProxyId)) and (thisRoomId == roomId) then
										tOutputRoomIdMap[providerOutputConnId] = roomId
									end
								end
							end
						end
					end
					func(providerDeviceProxyId)
				end

				func(audioEndPointDeviceProxyID)
			end
		end
		-- ************************************************************* --
	end

	return tOutputRoomIdMap
end

function GetProxyID(proxyConnectionId)
	local devs = C4:GetBoundConsumerDevices(0, proxyConnectionId)
	if (devs ~= nil) then
		for id, name in pairs(devs) do
			--should be only one
			return id
		end
	end
end

function GetRoomEndPointDeviceProxyID(roomId, roomConnId)
	--local roomId = C4:RoomGetId()
	local roomConnName = ROOM_CONN_ID_MAP[roomConnId]
	local providerDeviceProxyId = C4:GetBoundProviderDevice(roomId, roomConnId)
	if providerDeviceProxyId == 0 then providerDeviceProxyId = nil end -- room connection is not bound
	if providerDeviceProxyId then
		local providerName = C4:GetDeviceDisplayName(providerDeviceProxyId)
		print("'" .. C4:GetDeviceDisplayName(roomId) .. "' " .. roomConnName .. " device:", providerDeviceProxyId,
			providerName)
	else
		if not roomConnName then roomConnName = "Additional Video End-Point " .. tostring(roomConnId % 1000) end
		print("'" .. C4:GetDeviceDisplayName(roomId) .. "' " .. roomConnName .. " is not bound.")
	end

	return providerDeviceProxyId
end

--assumes only one consumer device is bound
function GetBoundConsumerDevice(deviceId, connectionId)
	local devsConsumer = C4:GetBoundConsumerDevices(deviceId, connectionId)
	if (devsConsumer ~= nil) then
		for idConsumer, nameConsumer in pairs(devsConsumer) do
			--print(idConsumer,nameConsumer)
			return tonumber(idConsumer), nameConsumer
		end
	else

	end
end

function GetNonbindingProviderDevice(proxyId, nonBindingConnectionId)
	local routingDeviceProxyId, routingDeviceDriverName
	local devs = C4:GetNonBindingProviderDevices(proxyId, nonBindingConnectionId)
	if (devs ~= nil) then
		for id, name in pairs(devs) do
			routingDeviceProxyId = tonumber(id)
			routingDeviceDriverName = name
		end
	end
	--print(routingDeviceProxyId, routingDeviceDriverName)

	return routingDeviceProxyId, routingDeviceDriverName
end

function GetAudioProviderOutputIdFromRoomId(roomId, mixerProxyId)
	local thisProxyId =  tonumber(GetProxyID(MAIN_PROXY_BINDING_ID)) or 0

	-- get Audio End-Point for requested room
	local audioEndPointDeviceProxyID = GetRoomEndPointDeviceProxyID(roomId, ROOM_CONN_ID_MAP["Audio End-Point 1"])
	if audioEndPointDeviceProxyID == nil then return nil end -- endpoint is not bound

	if tonumber(audioEndPointDeviceProxyID) == thisProxyId then
		for roomBindingConnId = 7000, 7000+#MIXER_ZONES.Zones-1 do
			local idConsumer, nameConsumer = GetBoundConsumerDevice(thisProxyId, roomBindingConnId)
			if idConsumer then
				print(idConsumer, nameConsumer)
				if idConsumer == roomId then
					return roomBindingConnId
				end
			end
		end
	else
		-- walk path back to determine audio output ID and return it
		local function func(_providerDeviceProxyId)
			--print('>>>>>', _providerDeviceProxyId)
			if _providerDeviceProxyId == 0 or _providerDeviceProxyId == nil then return end
			local providerDeviceProxyId = 0
			for consumerConnId = 3000, 3999 do
				providerDeviceProxyId = C4:GetBoundProviderDevice(_providerDeviceProxyId, consumerConnId)
				if tonumber(providerDeviceProxyId) == 0 then
					providerDeviceProxyId = GetNonbindingProviderDevice(providerDeviceProxyId, consumerConnId)
				end

				-- if the provider is our mixer then we have the correct output....
				if tonumber(providerDeviceProxyId) == thisProxyId then
					for providerOutputConnId = 4000, 4000+#MIXER_ZONES.Zones-1 do
						local consumerProxyId, consumerInputConnId = C4:GetBoundPartner(providerDeviceProxyId, providerOutputConnId, "STEREO")
						if consumerInputConnId then
							local thisRoomId, nameRoom = GetBoundConsumerDevice(_providerDeviceProxyId, 7000+consumerInputConnId%1000)
							if (consumerProxyId == tonumber(_providerDeviceProxyId)) and (thisRoomId == roomId) then
								return providerOutputConnId
							end
						end
					end
				end
			end

			return func(providerDeviceProxyId)
		end

		return func(audioEndPointDeviceProxyID)
	end
end