--[[=============================================================================
    File is: episode_dsp_device_specific.lua  (episode_dsp_device_specific)

    Copyright 2024 Snap One LLC.  All Rights Reserved.
===============================================================================]]

MIXER_CHANNELS = {}
MIXER_CHANNELS.Channels = {}

MIXER_ZONES = {}
MIXER_ZONES.Zones = {}

MIXER_MIXES = {}
MIXER_MIXES.Mixes = {}

MIXER_CONNECTIONS = {}

NUM_CHANNELS = 0
NUM_MIXES = 0
NUM_ZONES = 0
NUM_SOURCE_BIQUADS = 0

OutputRoomIdMap = {}
MAIN_PROXY_BINDING_ID = 5001

--Room Connection ID Map
ROOM_CONN_ID_MAP = {
	["Video End-Point"]           = 1,
	["Audio End-Point 1"]         = 2,
	["Video's Audio End-Point 1"] = 3,
	["Video Volume 1"]            = 4,
	["Audio Volume 1"]            = 5,
	["On-Screen Device"]          = 6,
	["Video Volume 2"]            = 8,
	["Audio Volume 2"]            = 10,
	["Temperature"]               = 12,
	["Temperature Control"]       = 13,
	["Security System"]           = 14,
	["IR Input Control"]          = 15,
	["Audio End-Point 2"]         = 16,
	["Video's Audio End-Point 2"] = 17,
	[1]                           = "Video End-Point",
	[2]                           = "Audio End-Point 1",
	[3]                           = "Video's Audio End-Point 1",
	[4]                           = "Video Volume 1",
	[5]                           = "Audio Volume 1",
	[6]                           = "On-Screen Device",
	[8]                           = "Video Volume 2",
	[10]                          = "Audio Volume 2",
	[12]                          = "Temperature",
	[13]                          = "Temperature Control",
	[14]                          = "Security System",
	[15]                          = "IR Input Control",
	[16]                          = "Audio End-Point 2",
	[17]                          = "Video's Audio End-Point 2",
}

-- Structure used for UI_REQUEST elements...
DEFAULT_MIXER_CHANNEL = {
  id = 0,
  order = 0,
  name = "",
  effects_panel_name = "",
  is_active = true,
  is_mono = false,
  is_muted = false,
  volume_mute_disabled = false,
  phantom_power = false,
  input_level = {
    _comment = "Episode key: gain",
    label = "Level",
    value = 0,
    unit = "dB",
    range = {
      min = -60,
      max = 24,
      step = 1
    }
  },
  type = {
    _comment = "Episode key: sourceType",
    value = "mic",
    options = { "mic", "line", "moip", "masking" }
  },
  input_gain = {
    _comment = "Episode key: preAmpGain",
    label = "Gain",
    value = 0,
    unit = "dB",
    range = {
      min = 0,
      max = 70, -- Range 0 - 24 for Line, 0-60 for Mic
      step = 1
    }
  },
  eq = {
    label = "EQ",
    enabled = true,
    bands = {
      {
        id = 1,
        freq = {
          label = "Frequency",
          value = 125,
          unit = "Hz",
          range = {
            min = 20,
            max = 20000,
            step = 1
          }
        },
        gain = {
          value = 0.0,
          unit = "dB",
          range = {
            min = -12,
            max = 12,
            step = 0.1
          }
        },
        q = {
          _comment = "Only adjustable for PARAMETRIC",
          label = "Q",
          value = 1,
          range = {
            min = .1,
            max = 9.1,
            step = 0.1
          }
        },
        type = {
          label = "Type",
          value = "LOW SHELF",
          options = { "PARAMETRIC", "LOW SHELF", "HIGH SHELF", "LOW PASS", "HIGH PASS" }
        },
        enabled = true
      },
      {
        id = 2,
        freq = {
          label = "Frequency",
          value = 500,
          unit = "Hz",
          range = {
            min = 20,
            max = 20000,
            step = 1
          }
        },
        gain = {
          value = 0.0,
          unit = "dB",
          range = {
            min = -12,
            max = 12,
            step = 0.1
          }
        },
        q = {
          _comment = "Only adjustable for PARAMETRIC",
          label = "Q",
          value = 1,
          range = {
            min = .1,
            max = 9.1,
            step = 0.1
          }
        },
        type = {
          label = "Type",
          value = "PARAMETRIC",
          options = { "PARAMETRIC", "LOW SHELF", "HIGH SHELF", "LOW PASS", "HIGH PASS" }
        },
        enabled = true
      },
      {
        id = 3,
        freq = {
          label = "Frequency",
          value = 2000,
          unit = "Hz",
          range = {
            min = 20,
            max = 20000,
            step = 1
          }
        },
        gain = {
          value = 0.0,
          unit = "dB",
          range = {
            min = -12,
            max = 12,
            step = 0.1
          }
        },
        q = {
          _comment = "Only adjustable for PARAMETRIC",
          label = "Q",
          value = 1,
          range = {
            min = .1,
            max = 9.1,
            step = 0.1
          }
        },
        type = {
          label = "Type",
          value = "HIGH SHELF",
          options = { "PARAMETRIC", "LOW SHELF", "HIGH SHELF", "LOW PASS", "HIGH PASS" }
        },
        enabled = true
      },
      {
        id = 4,
        freq = {
          label = "Frequency",
          value = 8000,
          unit = "Hz",
          range = {
            min = 20,
            max = 20000,
            step = 1
          }
        },
        gain = {
          value = 0.0,
          unit = "dB",
          range = {
            min = -12,
            max = 12,
            step = 0.1
          }
        },
        q = {
          _comment = "Only adjustable for PARAMETRIC",
          label = "Q",
          value = 1,
          range = {
            min = .1,
            max = 9.1,
            step = 0.1
          }
        },
        type = {
          label = "Type",
          value = "HIGH SHELF",
          options = { "PARAMETRIC", "LOW SHELF", "HIGH SHELF", "LOW PASS", "HIGH PASS" }
        },
        enabled = true
      }
    },
    low_cut_filter = {
      label = "Low Cut Filter",
      enabled = false,
      components = {
        {
          key = "freq",
          label = "Frequency",
          value = 80,
          unit = "Hz",
          range = {
            min = 20,
            max = 20000,
            step = 1
          }
        },
        {
          key = "slope",
          value = "6dB",
          options = { "6dB", "12dB" }
        }
      },
    }
  },
  compressor = {
    label = "Compressor",
    enabled = false,
    components = {
      {
        key = "threshold",
        label = "Threshold",
        value = 0,
        unit = "dB",
        range = {
          min = -60,
          max = 0,
          step = 1
        }
      },
      {
        key = "ratio",
        label = "Ratio",
        value = 1,
        unit = "",
        range = {
          min = 1,
          max = 20,
          step = 1
        }
      },
      {
        key = "release",
        label = "Release",
        value = 1,
        unit = "ms",
        range = {
          min = 1,
          max = 500,
          step = 1
        }
      },
      {
        key = "makeUp",
        label = "Make-up",
        value = 0,
        unit = "dB",
        range = {
          min = -12,
          max = 12,
          step = 1
        }
      },
      {
        key = "attack",
        label = "Attack",
        value = 1,
        unit = "ms",
        range = {
          min = 1,
          max = 500,
          step = 1
        }
      },
    },
  },
  noise_gate = {
    label = "Noise Gate",
    enabled = true,
    engaged = false,
    components = {
      {
        key = "threshold",
        label = "Threshold",
        value = 0,
        unit = "dB",
        range = {
          min = -60,
          max = 0,
          step = 1
        }
      },
      {
        key = "attack",
        label = "Attack",
        value = 1,
        unit = "ms",
        range = {
          min = 1,
          max = 500,
          step = 1
        }
      },
      {
        key = "hold",
        label = "Hold Time",
        value = 1,
        unit = "ms",
        range = {
          min = 1,
          max = 500,
          step = 1
        }
      },
      {
        key = "release",
        label = "Release",
        value = 1,
        unit = "ms",
        range = {
          min = 1,
          max = 500,
          step = 1
        }
      },
    },
  },
  de_esser = {
    label = "De-Esser",
    enabled = false,
    components = {
      {
        key = "frequency",
        label = "Frequency",
        value = 2000,
        unit = "Hz",
        range = {
          min = 2000,
          max = 10000,
          step = 1
        }
      },
      {
        key = "reduction",
        label = "Reduction",
        value = 0,
        unit = "Unit",
        range = {
          min = -10,
          max = 0,
          step = 1
        }
      },
      {
        key = "sensitivity",
        label = "Sensitivity",
        value = 0,
        unit = "Unit",
        range = {
          min = 0,
          max = 10,
          step = 1
        }
      },
      {
        key = "selectivity",
        label = "Selectivity",
        value = 0,
        unit = "Unit",
        range = {
          min = 0,
          max = 10,
          step = 1
        }
      },
    },
  },
}

DEFAULT_MIXER_ZONE = {
  room_id = 0,
  id = 0,
  is_mono = false,
  is_active = false,
  is_muted = false,
  name = "Zone 1",
  gain = 0,
  source = 0,          --sourceId 0 - 15 is direct source input, sourceId 16 - 19 is Mix 1 - Mix 4
  order = 0,
  source_audio_rx = 0, --for moip pairing
  source_group_rx = 0, --for moip pairing
  max_volume = 0,
  min_volume = -50,
}

DEFAULT_MIXER_MIX = {
  id = 0,
  is_mono = false,
  is_active = false,
  name = "MIX 1",
  channels = {},
}


function ON_DRIVER_INIT.MixerInit()

end

function ON_DRIVER_LATEINIT.MixerLateInit()
  MIXER_CHANNELS = PersistData.MIXER_CHANNELS or {}
  MIXER_CHANNELS.Channels = MIXER_CHANNELS.Channels or {}

  MIXER_ZONES = PersistData.MIXER_ZONES or {}
  MIXER_ZONES.Zones = MIXER_ZONES.Zones or {}

  MIXER_MIXES = PersistData.MIXER_MIXES or {}
  MIXER_MIXES.Mixes = MIXER_MIXES.Mixes or {}

  MIXER_CONNECTIONS = PersistData.MIXER_CONNECTIONS or {}

  MIXER_MESSAGES = PersistData.MIXER_MESSAGES or {}
  MIXER_MESSAGES.Messages = MIXER_MESSAGES.Messages or {}

  RoomIDs = PersistData.ROOM_IDS or {}
  OutputRoomIdMap = PersistData.OUTPUT_ROOM_MAP or {}

  EBMS_PRESETS = PersistData.EBMS_PRESETS or {}

  NUM_CHANNELS, NUM_ZONES = GetNumChannelsAndZones()

  GetMixerConnections()

  MixerReport_InitChannels(MIXER_CHANNELS) 
  MixerReport_InitZones(MIXER_ZONES)
  MixerReport_InitMixes(MIXER_MIXES)
end

function OnSystemEvent(event)
	local eventName = string.match(event, '.-name="(.-)"')

	if eventName == "OnPIP" then
    OutputRoomIdMap = GetAudioProviderOutputIdRoomIMap() or {}
	  PersistData.OUTPUT_ROOM_MAP = OutputRoomIdMap
  end

end

function GetNumChannelsAndZones()
  local num_channels = 0
  local num_zones = 0
  local strXML = C4:GetDriverConfigInfo('connections') or ''
  for connId in string.gmatch(strXML, '<id>(.-)</id>') do
    if (tonumber(connId) >= 3000) and (tonumber(connId) <= 3016) then
      num_channels = num_channels + 1
    elseif (tonumber(connId) >= 4000) and (tonumber(connId) <= 4099) then
      num_zones = num_zones + 1
    end
  end

  return num_channels, num_zones
end

function GetMixerConnections()
  MIXER_CONNECTIONS = {}
  local strXML = C4:GetDriverConfigInfo('connections') or ''
  for conn in string.gmatch(strXML, '<connection(.-)</connection>') do
    local connId = string.match(conn, '<id>(.-)</id>')
    local mixId = string.match(conn, '<mixid>(.-)</mixid>')
    local channelId = string.match(conn, '<channelid>(.-)</channelid>')
    if mixId then
      local t = { connId = connId, mixId = mixId }
      table.insert(MIXER_CONNECTIONS, t)
    elseif channelId then
      local t = { connId = connId, channelId = channelId }
      table.insert(MIXER_CONNECTIONS, t)
    end
    --print(connId, connName, mixId, channelId)
  end
  PersistData.MIXER_CONNECTIONS = MIXER_CONNECTIONS
  MixerReport_InitMixerConnections(MIXER_CONNECTIONS)
end

function IsMixConnection(connId)
  for _, conn in pairs(MIXER_CONNECTIONS) do
    if tonumber(conn.connId) == tonumber(connId) then
      if conn.mixId then
        return true
      else
        return false
      end
    end
  end
  return false
end

function GetMixId(sourceId)
  -- sourceId range: 3000 - 3999
  for _,conn in pairs(MIXER_CONNECTIONS) do
    if tonumber(conn.connId) == tonumber(sourceId) then
      return conn.mixId
    end
  end

  return -1

end

function GetChannelId(sourceId)
  -- sourceId range: 3000 - 3999
  for _,conn in pairs(MIXER_CONNECTIONS) do
    if tonumber(conn.connId) == tonumber(sourceId) then
      return conn.channelId
    end
  end

  return -1

end

function GetConnectionIdFromMixId(mixId)
  -- sourceId range: 3000 - 3999
  for _,conn in pairs(MIXER_CONNECTIONS) do
    if tonumber(conn.mixId) == tonumber(mixId) then
      return conn.connId
    end
  end

  return -1

end

function GetConnectionIdFromChannelId(channelId)
  -- sourceId range: 3000 - 3999
  for _,conn in pairs(MIXER_CONNECTIONS) do
    if tonumber(conn.channelId) == tonumber(channelId) then
      return conn.connId
    end
  end

  return -1

end

--[[=============================================================================
    Mixer Initialization
===============================================================================]]

------------------ Channels ------------------

function GetMixerChannelsForUI(sourceConnectionId, withDSP)
  local mixerChannels = {}
  mixerChannels.Channels = {}

  -- -1 indicates that no source/mix is currently routed/selected...
  if sourceConnectionId == -1 then
    table.insert(mixerChannels.Channels, nil)
    return mixerChannels
  end

  if not IsMixConnection(sourceConnectionId) then
    local mixerChannel = {}
    local channelId = GetChannelId(sourceConnectionId)
    if withDSP then
      mixerChannel = GetMixerChannel(channelId)
    else
      mixerChannel = GetMixerChannelWithoutDsp(channelId + 1)
    end
    table.insert(mixerChannels.Channels, deepcopy(mixerChannel))
    local source_label_tag = mixerChannel.source_label_tag or ""
    local channel_name = mixerChannels.Channels[#mixerChannels.Channels].name ..
        ": " .. source_label_tag
    channel_name = channel_name:gsub(":%s*$", "")
    mixerChannels.Channels[#mixerChannels.Channels].name = channel_name
    mixerChannels.Channels[#mixerChannels.Channels].volume_mute_disabled = true
  else -- source id 16 - 19 for mixes 1 - 4
    for _, mixerChannel in pairs(MIXER_CHANNELS.Channels) do
      local idChannel = mixerChannel.id
      local isMono = mixerChannel.is_mono
      local mixId = GetMixId(sourceConnectionId)
      local mixName, mixChannelVolume, mixChannelMute = GetMixChannel(mixId, idChannel, isMono)
      if IsMixerChannelActive(idChannel) then
        --table.insert(mixerChannels.Channels,deepcopy(mixerChannel))
        table.insert(mixerChannels.Channels, deepcopy(GetMixerChannelWithoutDsp(idChannel)))

        mixerChannels.Channels[#mixerChannels.Channels].input_level.value = mixChannelVolume
        mixerChannels.Channels[#mixerChannels.Channels].is_muted = mixChannelMute
        mixerChannels.Channels[#mixerChannels.Channels].input_level.range.min = -100
        mixerChannels.Channels[#mixerChannels.Channels].input_level.range.max = 0
        local source_label_tag = mixerChannel.source_label_tag or ""
        local mix_name = mixName ..
            ": " .. mixerChannel.name .. " " .. source_label_tag
        mix_name = mix_name:gsub(":%s*$", "")
        mixerChannels.Channels[#mixerChannels.Channels].name = mix_name
        mixerChannels.Channels[#mixerChannels.Channels].effects_panel_name = mixerChannel.name
        mixerChannels.Channels[#mixerChannels.Channels].volume_mute_disabled = false
      end
    end
  end

  return mixerChannels
end

function GetMixerChannelsForZoneUI(zoneId)
  local mixerChannels = {}
  mixerChannels.Channels = {}

  -- get source for this zone to build tag...
  local mixerZone = GetMixerZone(zoneId)
  local source = mixerZone.source
  local idChannel = source + 1
  for _, mixerChannel in pairs(MIXER_CHANNELS.Channels) do
    if IsMixerChannelActive(mixerChannel.id) then
      local t = {}
      t.id = mixerChannel.id
      if idChannel == mixerChannel.id then
        local source_label_tag = mixerChannel.source_label_tag or ""
        local channel_name = mixerChannel.name .. ": " .. source_label_tag
        channel_name = channel_name:gsub(":%s*$", "")
        t.name = channel_name
      else
        t.name = mixerChannel.name
      end
      table.insert(mixerChannels.Channels, t)
    end
  end

  -- Fix for EBMS-463. Mix ids are 17-20 on both 16x8 and 8x4 units
  for _, mixer_mix in pairs(MIXER_MIXES.Mixes) do
    if mixer_mix.is_active then
      local t = { id = mixer_mix.id + 16, name = mixer_mix.name }
      table.insert(mixerChannels.Channels, t)
    end
  end

  return mixerChannels
end

function IsMixerChannelActive(channel)
  if (channel <= 0) then return false end
  local is_active = MIXER_CHANNELS.Channels[channel] and MIXER_CHANNELS.Channels[channel].is_active

  return is_active
end

function GetMixerChannelType(channel)
  if (channel <= 0) then return end
  if (channel > NUM_CHANNELS) then return 'mix' end
  local type = MIXER_CHANNELS.Channels[channel] and MIXER_CHANNELS.Channels[channel].type.value

  return type
end

function GetMixerChannelWithoutDsp(channel)
  for _, mixerChannel in pairs(MIXER_CHANNELS.Channels) do
    if tonumber(mixerChannel.id) == tonumber(channel) then
      local t = {}
      for k, v in pairs(mixerChannel) do
        if (k ~= "eq") and (k ~= "compressor") and (k ~= "noise_gate") and (k ~= "de_esser") then
          t[k] = v
        end
      end

      return t
    end
  end

  --NOTE: Since this function is called from the C4 UI we should not hit this block as the channel should already exits...
  -- channel data does not exist so create default...
  table.insert(MIXER_CHANNELS.Channels, deepcopy(DEFAULT_MIXER_CHANNEL_MIC))
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].id = channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].name = "Source " .. channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].effects_panel_name = "Source " .. channel

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS

  return MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels]
end

function GetMixerChannel(channel)
  for _, mixerChannel in pairs(MIXER_CHANNELS.Channels) do
    if tonumber(mixerChannel.id) == tonumber(channel) then
      return mixerChannel
    end
  end

  table.insert(MIXER_CHANNELS.Channels, deepcopy(DEFAULT_MIXER_CHANNEL))
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].id = channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].name = "Source " .. channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].effects_panel_name = "Source " .. channel

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS

  return MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels]
end

function GetMixerChannelEqBand(channel, eqBand)
  for _, mixerChannel in pairs(MIXER_CHANNELS.Channels) do
    if tonumber(mixerChannel.id) == tonumber(channel) then
      if mixerChannel.eq == nil then return nil end
      for _, band in pairs(mixerChannel.eq.bands) do
        if band.id == eqBand then
          return band
        end
      end
      return nil
    end
  end

  -- channel data does not exist so create default...
  table.insert(MIXER_CHANNELS.Channels, deepcopy(DEFAULT_MIXER_CHANNEL_MIC))
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].id = channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].name = "Source " .. channel
  MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels].effects_panel_name = "Source " .. channel

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS

  local mixerChannel = MIXER_CHANNELS.Channels[#MIXER_CHANNELS.Channels]
  for _, band in pairs(mixerChannel.eq.bands) do
    if band.id == eqBand then
      return band
    end
  end
  return nil
end

-- NOTE: Component keys are dynamic for each driver depending on what is supported by the device
-- For EBMS Compressor keys are threshold, ratio, release, makeUp, attack
function GetCompressorComponent(compressor_components, component_key)
  for k, v in ipairs(compressor_components) do
    if v.key == component_key then return v end
  end
end

-- NOTE: Noise Gate keys are dynamic for each driver depending on what is supported by the device
-- For EBMS Noise Gate keys are threshold, attack, hold, release
function GetNoiseGateComponent(noise_gate_components, component_key)
  for k, v in ipairs(noise_gate_components) do
    if v.key == component_key then return v end
  end
end

-- NOTE: De-Esser keys are dynamic for each driver depending on what is supported by the device
-- For EBMS De-Esser keys are frequency, reduction, sensitivity, selectivity
function GetDeEsserComponent(de_esser_components, component_key)
  for k, v in ipairs(de_esser_components) do
    if v.key == component_key then return v end
  end
end

------------------ Mixes ------------------

function GetMixerMix(mix)
  for _, mixerMix in pairs(MIXER_MIXES.Mixes) do
    if tonumber(mixerMix.id) == tonumber(mix) then
      return mixerMix
    end
  end

  -- mix data does not exist so create default...
  table.insert(MIXER_MIXES.Mixes, deepcopy(DEFAULT_MIXER_MIX))
  MIXER_MIXES.Mixes[#MIXER_MIXES.Mixes].id = mix
  MIXER_MIXES.Mixes[#MIXER_MIXES.Mixes].name = "MIX " .. mix

  PersistData.MIXER_MIXES = MIXER_MIXES

  return MIXER_MIXES.Mixes[#MIXER_MIXES.Mixes]
end

function GetMixChannel(mixId, channelId, channelIsMono)
  local mixerMix = GetMixerMix(mixId)

  local mixName = mixerMix.name
  --local mixIsMono = mixerMix.isMono
  --local mixIsActive = mixerMix.is_active

  local channelVolume = mixerMix.channels[channelId].volume
  local channelMute = mixerMix.channels[channelId].is_muted


  return mixName, channelVolume, channelMute
end

------------------ Zones ------------------

function GetMixerZone(zone)
  for _, mixerZone in pairs(MIXER_ZONES.Zones) do
    if tonumber(mixerZone.id) == tonumber(zone) then
      return mixerZone
    end
  end

  -- zone data does not exist so create default...
  table.insert(MIXER_ZONES.Zones, deepcopy(DEFAULT_MIXER_ZONE))
  MIXER_ZONES.Zones[#MIXER_ZONES.Zones].id = zone
  MIXER_ZONES.Zones[#MIXER_ZONES.Zones].name = "ZONE" .. zone

  PersistData.MIXER_ZONES = MIXER_ZONES

  return MIXER_ZONES.Zones[#MIXER_ZONES.Zones]
end

function GetMixerZoneFromRoomId(room_id)
  for _, mixerZone in pairs(MIXER_ZONES.Zones) do
    if tonumber(mixerZone.room_id) == tonumber(room_id) then
      return mixerZone
    end
  end

  return nil
end

--------------------------------------------

function deepcopy(orig)
  local orig_type = type(orig)
  local copy
  if orig_type == 'table' then
    copy = {}
    for orig_key, orig_value in next, orig, nil do
      copy[deepcopy(orig_key)] = deepcopy(orig_value)
    end
    setmetatable(copy, deepcopy(getmetatable(orig)))
  else -- number, string, boolean, etc
    copy = orig
  end
  return copy
end

--[[==========================================================================================
	Driver Template Functions
============================================================================================]]

function HandleMessage(message)
  LogTrace("HandleMessage. Message is ==>")
  LogTrace(message)

  -- zoneId & channelId must be 1 based (for correlation to output & input connectionId)
  -- assumption that Output Connection Ids are 0 based and Input Connection Ids are 1 based...

  -- NOTE: This is only a sample structue for the message
  -- and will need to be modified based upon the actual device data structure
  if message.messageType == "channel" then
    local channelId = message.channelId

    if message.payloadType == "channel_order" then
      DEV_MSG.CHANNEL_ORDER({channelId = channelId, order = message.payload})
    elseif message.payloadType == "channel_is_mono" then
      DEV_MSG.CHANNEL_IS_MONO({channelId = channelId, isMono = message.payload})
    elseif message.payloadType == "channel_name" then
      DEV_MSG.CHANNEL_NAME({channelId = channelId, name = message.payload})
    elseif message.payloadType == "channel_type" then
      DEV_MSG.CHANNEL_TYPE({channelId = channelId, channelType = message.payload})
    elseif message.payloadType == "channel_phantom_power" then
      DEV_MSG.CHANNEL_PHANTOM_POWER({channelId = channelId, phantomPower = message.payload})
    elseif message.payloadType == "channel_is_active" then
      DEV_MSG.CHANNEL_ACTIVE({channelId = channelId, isActive = message.payload})
    elseif message.payloadType == "channel_is_muted" then
      DEV_MSG.CHANNEL_MUTE({channelId = channelId, IsMuted = message.payload})
    elseif message.payloadType == "channel_pre-amp_gain" then
      DEV_MSG.CHANNEL_PREAMP_GAIN({channelId = channelId, preAmpGain = message.payload})
    elseif message.payloadType == "channel_gain" then
      DEV_MSG.CHANNEL_GAIN({channelId = channelId, gain = message.payload})
    end

  elseif message.messageType == "channel_eq" then
    local channelId = message.channelId
    local bandId = message.bandId

    if message.payloadType == "eq_enabled" then
      DEV_MSG.CHANNEL_EQ_ENABLED({channelId = channelId, enabled = message.payload})
    elseif message.payloadType == "eq_band_enabled" then
      DEV_MSG.CHANNEL_EQ_BAND_ENABLED({channelId = channelId, bandId = bandId, enabled = message.payload})
    elseif message.payloadType == "eq_band_frequency" then
      DEV_MSG.CHANNEL_EQ_BAND_FREQUENCY({channelId = channelId, bandId = bandId, frequency = message.payload})
    elseif message.payloadType == "eq_band_gain" then
      DEV_MSG.CHANNEL_EQ_BAND_GAIN({channelId = channelId, bandId = bandId, gain = message.payload})
    elseif message.payloadType == "eq_band_q" then
      DEV_MSG.CHANNEL_EQ_BAND_Q({channelId = channelId, bandId = bandId, q = message.payload})
    elseif message.payloadType == "eq_band_type" then
      DEV_MSG.CHANNEL_EQ_BAND_TYPE({channelId = channelId, bandId = bandId, type = message.payload})
    end

  elseif message.messageType == "channel_compressor" then
    local channelId = message.channelId

    if message.payloadType == "compressor_enabled" then
      DEV_MSG.CHANNEL_COMPRESSOR_ENABLED({channelId = channelId, enabled = message.payload})
    elseif message.payloadType == "compressor_threshold" then
      DEV_MSG.CHANNEL_COMPRESSOR_THRESHOLD({channelId = channelId, threshhold = message.payload})
    elseif message.payloadType == "compressor_ratio" then
      DEV_MSG.CHANNEL_COMPRESSOR_RATIO({channelId = channelId, ratio = message.payload})
    elseif message.payloadType == "compressor_attack" then
      DEV_MSG.CHANNEL_COMPRESSOR_ATTACK({channelId = channelId, attack = message.payload})
    elseif message.payloadType == "compressor_release" then
      DEV_MSG.CHANNEL_COMPRESSOR_RELEASE({channelId = channelId, release = message.payload})
    elseif message.payloadType == "compressor_make_up" then
      DEV_MSG.CHANNEL_COMPRESSOR_MAKE_UP({channelId = channelId, makeUp = message.payload})
    end

  elseif message.messageType == "channel_noise_gate" then
    local channelId = message.channelId

    if message.payloadType == "noise_gate_enabled" then
      DEV_MSG.CHANNEL_NOISE_GATE_ENABLED({channelId = channelId, enabled = message.payload})
    elseif message.payloadType == "noise_gate_threshold" then
      DEV_MSG.CHANNEL_NOISE_GATE_THRESHOLD({channelId = channelId, threshold = message.payload})
    elseif message.payloadType == "noise_gate_attack" then
      DEV_MSG.CHANNEL_NOISE_GATE_ATTACK({channelId = channelId, attack = message.payload})
    elseif message.payloadType == "noise_gate_release" then
      DEV_MSG.CHANNEL_NOISE_GATE_RELEASE({channelId = channelId, release = message.payload})
    elseif message.payloadType == "noise_gate_hold" then
      DEV_MSG.CHANNEL_NOISE_GATE_HOLD({channelId = channelId, hold = message.payload})
    end

  elseif message.messageType == "channel_de_essser" then
    local channelId = message.channelId

    if message.payloadType == "de_esser_enabled" then
      DEV_MSG.CHANNEL_DE_ESSER_ENABLED({channelId = channelId, enabled = message.payload})
    elseif message.payloadType == "de_esser_frequency" then
      DEV_MSG.CHANNEL_DE_ESSER_FREQUENCY({channelId = channelId, frequency = message.payload})
    elseif message.payloadType == "de_esser_reduction" then
      DEV_MSG.CHANNEL_DE_ESSER_REDUCTION({channelId = channelId, reduction = message.payload})
    elseif message.payloadType == "de_esser_sensitivity" then
      DEV_MSG.CHANNEL_DE_ESSER_SENSITIVITY({channelId = channelId, sensitivity = message.payload})
    elseif message.payloadType == "de_esser_selectivity" then
      DEV_MSG.CHANNEL_DE_ESSER_SELECTIVITY({channelId = channelId, selectivity = message.payload})
    end

  elseif message.messageType == "mix" then
    local mixId = message.mixId
    local channelId = message.mixChannelId

    if message.payloadType == "mix_channel_mute" then
      DEV_MSG.MIX_CHANNEL_MUTE({mixId = mixId, channelId = channelId, isMuted = message.payload})
    elseif message.payloadType == "mix_channel_gain" then
      DEV_MSG.MIX_CHANNEL_GAIN({mixId = mixId, channelId = channelId, gain = message.payload})
    elseif message.payloadType == "mix_channel_is_active" then
      DEV_MSG.MIX_IS_ACTIVE({mixId = mixId, channelId = channelId, isActive = message.payload})
    elseif message.payloadType == "mix_channel_name" then
      DEV_MSG.MIX_NAME({mixId = mixId, name = message.payload})
    elseif message.payloadType == "mix_channel_is_mono" then
      DEV_MSG.MIX_IS_MONO({mixId = mixId, isMono = message.payload})
    end

  elseif message.messageType == "zone" then
    local zoneId = message.zoneId

    if message.payloadType == "zone_order" then
      DEV_MSG.ZONE_ORDER({zoneId = zoneId, order = message.payload})
    elseif message.payloadType == "zone_name" then
      DEV_MSG.ZONE_NAME({zoneId = zoneId, name = message.payload})
    elseif message.payloadType == "zone_is_avtive" then
      DEV_MSG.ZONE_IS_ACTIVE({zoneId = zoneId, isActive = message.payload})
    elseif message.payloadType == "zone_is_mono" then
      DEV_MSG.ZONE_IS_MONO({zoneId = zoneId, isMono = message.payload})
    elseif message.payloadType == "zone_is_muted" then
      DEV_MSG.ZONE_MUTE({zoneId = zoneId, IsMuted = message.payload})
    elseif message.payloadType == "zone_gain" then
      DEV_MSG.ZONE_GAIN({zoneId = zoneId, gain = message.payload})
    elseif message.payloadType == "zone_source" then
      DEV_MSG.ZONE_SOURCE({zoneId = zoneId, channelId = message.payload})
    end

  elseif message.messageType == "count" then

    DEV_MSG.COUNT(message.payload)

  end

end


--[[=============================================================================
    Count Messages
===============================================================================]]
function DEV_MSG.COUNT(count) -- still missing biquad
  LogTrace("DEV_MSG.COUNT. Message is ==>")
  LogTrace(count)
  if (tonumber(count.zoneCount)) then
    NUM_ZONES = tonumber(count.zoneCount)
  elseif (tonumber(count.outputCount)) then
    NUM_OUTPUTS = tonumber(count.outputCount)
  elseif (tonumber(count.messageCount)) then
    NUM_MESSAGES = tonumber(count.messageCount)
  elseif (tonumber(count.inputCount)) then
    NUM_INPUTS = tonumber(count.inputCount)
  elseif (tonumber(count.moipCount)) then
    NUM_MOIP_RXS = tonumber(count.moipCount)
  elseif (tonumber(count.sourceCount)) then
    NUM_CHANNELS = tonumber(count.sourceCount)
  end
end

--[[=============================================================================
    Mixer Messages
===============================================================================]]
function DEV_MSG.CHANNEL_ORDER(Params)
  LogTrace("DEV_MSG.CHANNEL_ORDER. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local order = Params.order

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.order = tonumber(order)
  local params = {id = channelId, order = order}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_IS_MONO(Params)
  LogTrace("DEV_MSG.CHANNEL_MONO. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local isMono = toboolean(Params.isMono)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.is_mono = isMono
  local params = {id = channelId, is_mono = isMono}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NAME(Params)
  LogTrace("DEV_MSG.CHANNEL_NAME. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local name = Params.name

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.name = name
  mixerChannel.effects_panel_name = name

  local params = {id = channelId, name = name, effects_panel_name = name}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_TYPE(Params)
  LogTrace("DEV_MSG.CHANNEL_TYPE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local channelType = Params.ChannelType

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.type.value = channelType

  local params = {id = channelId, type = {value = channelType}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_PHANTOM_POWER(Params)
  LogTrace("DEV_MSG.CHANNEL_PHANTOM_POWER. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local phantomPower = toboolean(Params.phantomPower)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.phantom_power = phantomPower

  local params = {id = channelId, phantom_power = phantomPower}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_ACTIVE(Params)
  LogTrace("DEV_MSG.CHANNEL_ACTIVE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local isActive = toboolean(Params.isActive)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.is_active = isActive

  local params = {id = channelId, is_active = isActive}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_MUTE(Params)
  LogTrace("DEV_MSG.CHANNEL_MUTE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local isMuted = toboolean(Params.isMuted)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.is_muted = isMuted

  local params = {id = channelId, is_muted = isMuted}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_PREAMP_GAIN(Params)
  LogTrace("DEV_MSG.CHANNEL_PREAMP_GAIN. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local preAmpGain = tonumber(Params.preAmpGain)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.input_gain.value = preAmpGain

  local params = {id = channelId, input_gain = {value = preAmpGain}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_GAIN(Params)
  LogTrace("DEV_MSG.CHANNEL_GAIN. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local gain = tonumber(Params.gain)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.input_level.value = gain

  local params = {id = channelId, input_level = {value = gain}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_ENABLED(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_ENABLED. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local enabled = toboolean(Params.enabled)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.eq.enabled = enabled

  local params = {id = channelId, eq = {enabled = enabled}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_BAND_ENABLED(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_BAND_ENABLED. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local bandId = tonumber(Params.bandId)
  local enabled = toboolean(Params.enabled)

  local mixerChannelEqBand = GetMixerChannelEqBand(channelId, bandId)
  mixerChannelEqBand.enabled = enabled

  local params = {id = channelId, eq = {bands = { id = bandId, enabled = enabled }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_BAND_FREQUENCY(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_BAND_FREQUENCY. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local bandId = tonumber(Params.bandId)
  local frequency = tonumber(Params.frequency)

  local mixerChannelEqBand = GetMixerChannelEqBand(channelId, bandId) or {}
  mixerChannelEqBand.freq = mixerChannelEqBand.freq or {}
  mixerChannelEqBand.freq.value = frequency

  local params = {id = channelId, eq = {bands = { id = bandId, freq = { value = frequency } }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_BAND_GAIN(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_BAND_GAIN. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local bandId = tonumber(Params.bandId)
  local gain = tonumber(Params.gain)

  local mixerChannelEqBand = GetMixerChannelEqBand(channelId, bandId) or {}
  mixerChannelEqBand.freq = mixerChannelEqBand.freq or {}
  mixerChannelEqBand.gain.value = gain

  local params = {id = channelId, eq = {bands = { id = bandId, gain = { value = gain } }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_BAND_Q(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_BAND_Q. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local bandId = tonumber(Params.bandId)
  local q = tonumber(Params.q)

  local mixerChannelEqBand = GetMixerChannelEqBand(channelId, bandId) or {}
  mixerChannelEqBand.q = mixerChannelEqBand.q or {}
  mixerChannelEqBand.q.value = q

  local params = {id = channelId, eq = {bands = { id = bandId, q = { value = q } }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_EQ_BAND_TYPE(Params)
  LogTrace("DEV_MSG.CHANNEL_EQ_BAND_TYPE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local bandId = tonumber(Params.bandId)
  local type = tonumber(Params.type)

  local mixerChannelEqBand = GetMixerChannelEqBand(channelId, bandId) or {}
  mixerChannelEqBand.type = mixerChannelEqBand.type or {}
  mixerChannelEqBand.type.value = type

  local params = {id = channelId, eq = {bands = { id = bandId, type = { value = type } }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_ENABLED(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_ENABLED. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local enabled = toboolean(Params.enabled)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.compressor.enabled = enabled

  local params = {id = channelId, compressor = {enabled = enabled}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_THRESHOLD(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_THRESHOLD. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.threshold)

  local mixerChannel = GetMixerChannel(channelId)
  local threshold = GetCompressorComponent(mixerChannel.compressor.components, "threshold")
  threshold.value = value

  local params = {id = channelId, compressor = {components = { key = "threshold", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_RATIO(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_RATIO. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.ratio)

  local mixerChannel = GetMixerChannel(channelId)
  local ratio = GetCompressorComponent(mixerChannel.compressor.components, "ratio")
  ratio.value = value

  local params = {id = channelId, compressor = {components = { key = "ratio", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_ATTACK(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_ATTACK. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.attack)

  local mixerChannel = GetMixerChannel(channelId)
  local attack = GetCompressorComponent(mixerChannel.compressor.components, "attack")
  attack.value = value

  local params = {id = channelId, compressor = {components = { key = "attack", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_RELEASE(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_RELEASE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.release)

  local mixerChannel = GetMixerChannel(channelId)
  local release = GetCompressorComponent(mixerChannel.compressor.components, "release")
  release.value = value

  local params = {id = channelId, compressor = {components = { key = "release", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_COMPRESSOR_MAKE_UP(Params)
  LogTrace("DEV_MSG.CHANNEL_COMPRESSOR_MAKE_UP. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.makeUp)

  local mixerChannel = GetMixerChannel(channelId)
  local makeUp = GetCompressorComponent(mixerChannel.compressor.components, "makeUp")
  makeUp.value = value

  local params = {id = channelId, compressor = {components = { key = "makeUp", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NOISE_GATE_ENABLED(Params)
  LogTrace("DEV_MSG.CHANNEL_NOISE_GATE_ENABLED. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local enabled = toboolean(Params.enabled)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.noise_gate.enabled = enabled

  local params = {id = channelId, noise_gate = {enabled = enabled}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NOISE_GATE_THRESHOLD(Params)
  LogTrace("DEV_MSG.CHANNEL_NOISE_GATE_THRESHOLD. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.threshold)

  local mixerChannel = GetMixerChannel(channelId)
  local threshold = GetNoiseGateComponent(mixerChannel.noise_gate.components, "threshold")
  threshold.value = value

  local params = {id = channelId, noise_gate = {components = { key = "threshold", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NOISE_GATE_ATTACK(Params)
  LogTrace("DEV_MSG.CHANNEL_NOISE_GATE_ATTACK. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.attack)

  local mixerChannel = GetMixerChannel(channelId)
  local attack = GetNoiseGateComponent(mixerChannel.noise_gate.components, "attack")
  attack.value = value

  local params = {id = channelId, noise_gate = {components = { key = "attack", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NOISE_GATE_RELEASE(Params)
  LogTrace("DEV_MSG.CHANNEL_NOISE_GATE_RELEASE. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.release)

  local mixerChannel = GetMixerChannel(channelId)
  local release = GetNoiseGateComponent(mixerChannel.noise_gate.components, "release")
  release.value = value

  local params = {id = channelId, noise_gate = {components = { key = "release", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_NOISE_GATE_HOLD(Params)
  LogTrace("DEV_MSG.CHANNEL_NOISE_GATE_HOLD. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.hold)

  local mixerChannel = GetMixerChannel(channelId)
  local hold = GetNoiseGateComponent(mixerChannel.noise_gate.components, "hold")
  hold.value = value

  local params = {id = channelId, noise_gate = {components = { key = "hold", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_DE_ESSER_ENABLED(Params)
  LogTrace("DEV_MSG.CHANNEL_DE_ESSER_ENABLED. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local enabled = toboolean(Params.enabled)

  local mixerChannel = GetMixerChannel(channelId)
  mixerChannel.de_esser.enabled  = enabled

  local params = {id = channelId, de_esser = {enabled = enabled}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_DE_ESSER_FREQUENCY(Params)
  LogTrace("DEV_MSG.CHANNEL_DE_ESSER_FREQUENCY. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.frequency)

  local mixerChannel = GetMixerChannel(channelId)
  local frequency = GetDeEsserComponent(mixerChannel.de_esser.components, "frequency")
  frequency.value = value

  local params = {id = channelId, de_esser = {components = { key = "frequency", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_DE_ESSER_REDUCTION(Params)
  LogTrace("DEV_MSG.CHANNEL_DE_ESSER_REDUCTION. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.reduction)

  local mixerChannel = GetMixerChannel(channelId)
  local reduction = GetDeEsserComponent(mixerChannel.de_esser.components, "reduction")
  reduction.value = value

  local params = {id = channelId, de_esser = {components = { key = "reduction", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_DE_ESSER_SENSITIVITY(Params)
  LogTrace("DEV_MSG.CHANNEL_DE_ESSER_SENSITIVITY. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.sensitivity)

  local mixerChannel = GetMixerChannel(channelId)
  local sensitivity = GetDeEsserComponent(mixerChannel.de_esser.components, "sensitivity")
  sensitivity.value = value

  local params = {id = channelId, de_esser = {components = { key = "sensitivity", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function DEV_MSG.CHANNEL_DE_ESSER_SELECTIVITY(Params)
  LogTrace("DEV_MSG.CHANNEL_DE_ESSER_SELECTIVITY. Message ==> (%s)", table.concat(Params))
  local channelId = tonumber(Params.channelId)
  local value = tonumber(Params.selectivity)

  local mixerChannel = GetMixerChannel(channelId)
  local selectivity = GetDeEsserComponent(mixerChannel.de_esser.components, "selectivity")
  selectivity.value = value

  local params = {id = channelId, de_esser = {components = { key = "selectivity", value = value }}}
  sendChannelNotification(params)

  PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function sendChannelNotification(notify)
  local mixId = notify.mixConnectionId
  notify.mixConnectionId = nil
  local source = notify.id - 1
  for zoneId = 1, NUM_ZONES do
    local zone = GetMixerZone(zoneId)
    local tNotify = deepcopy(notify)
    tNotify.RoomId = zone.room_id
    local isActive = zone.is_active

    -- if this source is current source OR it is part of a mix that is the current source
    -- then add the room_id and send the notification
    -- except for level, need to check is room source is ONLY this channel, not part of a mix...
    if isActive and tNotify.RoomId then
      -- if mixId exists, that means that sendChannelNotification is caused by a mix change
      if (mixId) then -- mix info is received
        if zone.source == mixId then
          NOTIFY.CHANNEL_CHANGED(tNotify)
        end
      else --single source info is received
        -- info should be sent if zone is connected to the source with that id
        -- or if zone is connected to a mix (because all channels are part of every mix)
        if zone.source == source or zone.source >= NUM_CHANNELS then
          NOTIFY.CHANNEL_CHANGED(tNotify)
        end
      end
    end
  end
end

function DEV_MSG.MIX_CHANNEL_MUTE(Params)
  LogTrace("DEV_MSG.MIX_CHANNEL_MUTE. Message ==> (%s)", table.concat(Params))
  local mixId = tonumber(Params.mixId)
  local channelId = tonumber(Params.channelId)
  local isMuted = toboolean(Params.isMuted)
  local mixConnectionId = GetConnectionIdFromMixId(mixId)
  local mixerMix = GetMixerMix(mixId)

  if (not GetAllZonesInProgress and mixerMix.channels[channelId].is_muted ~= isMuted) then
    sendChannelNotification({ id = channelId, is_muted = isMuted, mixConnectionId = mixConnectionId })
  end

  mixerMix.channels[channelId].is_muted = isMuted
  NOTIFY.MIX_CHANGED({ id = mixId, channel_id = channelId, is_muted = isMuted })

  PersistData.MIXER_MIXES = MIXER_MIXES
end

function DEV_MSG.MIX_CHANNEL_GAIN(Params)
  LogTrace("DEV_MSG.MIX_CHANNEL_GAIN. Message ==> (%s)", table.concat(Params))
  local mixId = tonumber(Params.mixId)
  local channelId = tonumber(Params.channelId)
  local gain = tonumber(Params.gain)
  local mixConnectionId = GetConnectionIdFromMixId(mixId)
  local mixerMix = GetMixerMix(mixId)

  if (not GetAllZonesInProgress and mixerMix.channels[channelId].volume ~= gain) then
    local params = { id = channelId, input_level = { value = gain }, mixConnectionId = mixConnectionId }
    sendChannelNotification(params)
  end

  mixerMix.channels[channelId].volume = gain
  NOTIFY.MIX_CHANGED({ id = mixId, channel_id = channelId, volume = gain })

  PersistData.MIXER_MIXES = MIXER_MIXES
end

function DEV_MSG.MIX_IS_ACTIVE(Params)
  LogTrace("DEV_MSG.MIX_CHANNEL_IS_ACTIVE. Message ==> (%s)", table.concat(Params))
  local mixId = tonumber(Params.mixId)
  local channelId = tonumber(Params.channelId)
  local isActive = toboolean(Params.isActive)
  local mixConnectionId = GetConnectionIdFromMixId(mixId)
  local mixerMix = GetMixerMix(mixId)

  if (not GetAllZonesInProgress and mixerMix.is_active ~= isActive) then
    local params = { id = channelId, is_active = isActive, mixConnectionId = mixConnectionId }
    sendChannelNotification(params)
  end
  mixerMix.is_active = isActive
  NOTIFY.MIX_CHANGED({ id = mixId, is_active = isActive })

  PersistData.MIXER_MIXES = MIXER_MIXES
end

function DEV_MSG.MIX_NAME(Params)
  LogTrace("DEV_MSG.MIX_CHANNEL_NAME. Message ==> (%s)", table.concat(Params))
  local mixId = tonumber(Params.mixId)
  local name = toboolean(Params.name)
  local mixConnectionId = GetConnectionIdFromMixId(mixId)
  local mixerMix = GetMixerMix(mixId)

  if (mixerMix.name ~= name) then
    mixerMix.name = name
    NOTIFY.MIX_CHANGED({ id = mixId, name = name })
    local mixesInfo = GetMixerChannelsForUI(mixConnectionId)
    for channelId, channelInfo in pairs(mixesInfo.Channels) do
      local params = { id = tonumber(channelId), name = tostring(channelInfo.name), mixConnectionId = mixConnectionId }
      sendChannelNotification(params)
    end
  end

  PersistData.MIXER_MIXES = MIXER_MIXES
end

function DEV_MSG.MIX_IS_MONO(Params)
  LogTrace("DEV_MSG.MIX_CHANNEL_IS_MONO. Message ==> (%s)", table.concat(Params))
  local mixId = tonumber(Params.mixId)
  local isMono = toboolean(Params.isMono)
  local mixerMix = GetMixerMix(mixId)

  mixerMix.is_mono = isMono
  NOTIFY.MIX_CHANGED({ id = mixId, is_mono = isMono })

  PersistData.MIXER_MIXES = MIXER_MIXES
end

function DEV_MSG.ZONE_ORDER(Params)
  LogTrace("DEV_MSG.ZONE_ORDER. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local order = tonumber(Params.order)

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId
  mixerZone.order = order

  local params = { id = zoneId, RoomId = RoomId, order = order }
  sendZoneNotification(params)

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_NAME(Params)
  LogTrace("DEV_MSG.ZONE_NAME. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local name = Params.name

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId
  mixerZone.name = name

  local params = { id = zoneId, RoomId = RoomId, name = name }
  sendZoneNotification(params)

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_IS_ACTIVE(Params)
  LogTrace("DEV_MSG.ZONE_IS_ACTIVE. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local isActive = toboolean(Params.isActive)

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId
  mixerZone.is_active = isActive

  local params = { id = zoneId, RoomId = RoomId, is_active = isActive }
  sendZoneNotification(params)

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_IS_MONO(Params)
  LogTrace("DEV_MSG.ZONE_IS_MONO. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local isMono = toboolean(Params.isMono)

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId
  mixerZone.is_mono = isMono

  local params = { id = zoneId, RoomId = RoomId, is_mono = isMono }
  sendZoneNotification(params)

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_MUTE(Params)
  LogTrace("DEV_MSG.ZONE_MUTE. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local isMuted = toboolean(Params.isMuted)

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId

  if mixerZone.is_muted ~= isMuted then
    mixerZone.is_muted = isMuted
    local params = { id = zoneId, RoomId = RoomId, is_muted = isMuted }
    sendZoneNotification(params)

    local OutputBinding = GetOutputIdFromZoneId(zoneId)
    if OutputBinding ~= nil then
      local Mute = "False"
      if isMuted == true then Mute = "True" end
      NOTIFY.AVS_MUTE_CHANGED(Mute, OutputBinding, 5001)
    end
  end

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_GAIN(Params)
  LogTrace("DEV_MSG.ZONE_GAIN. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local gain = tonumber(Params.gain) or 0

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId

  mixerZone.gain = gain
  local params = { id = zoneId, RoomId = RoomId, gain = gain }
  sendZoneNotification(params)

  local OutputBinding = GetOutputIdFromZoneId(zoneId)
  if OutputBinding ~= nil then
    local min_volume = mixerZone.min_volume
    local max_volume = mixerZone.max_volume
    local level = ConvertVolumeToC4(gain, min_volume, max_volume)
    NOTIFY.AVS_VOLUME_LEVEL_CHANGED(level, OutputBinding, 5001)
  end

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function DEV_MSG.ZONE_SOURCE(Params)
  LogTrace("DEV_MSG.ZONE_SOURCE. Message ==> (%s)", table.concat(Params))
  local zoneId = tonumber(Params.zoneId)
  local RoomId = OutputRoomIdMap[zoneId + 7000 - 1] or OutputRoomIdMap[zoneId + 4000 - 1]
  local source = tonumber(Params.channelId) or 0
  local sourceConnId = GetSourceConnId(source)

  local mixerZone = GetMixerZone(zoneId)
  mixerZone.room_id = RoomId
  mixerZone.source = source
  mixerZone.sourceConnId = sourceConnId

  local params = { id = zoneId, RoomId = RoomId, source = source, sourceConnId = sourceConnId }
  sendZoneNotification(params)

  local OutputBinding = GetOutputIdFromZoneId(zoneId)
  if OutputBinding ~= nil then
    NOTIFY.AVS_INPUT_OUTPUT_CHANGED(tonumber(GetSourceConnId(mixerZone.source)), OutputBinding, true, AVSWITCH_BINDING_ID)
  end

  -- channel/mix has changed, need to rebuild UI...
  local mixer_channels = GetMixerChannelsForUI(tonumber(source)) or {}
  local tChannelsNotify = mixer_channels
  tChannelsNotify.RoomId = RoomId
  sendChannelsNotification(tChannelsNotify)

  PersistData.MIXER_ZONES = MIXER_ZONES
end

function GetOutputIdFromZoneId(zone_id)
  local output_id = 4000 + zone_id - 1
  if OutputRoomIdMap[output_id] ~= nil then
    return output_id
  else
    output_id = 7000 + zone_id - 1
    if OutputRoomIdMap[output_id] ~= nil then
      return output_id
    else
      return nil
    end
  end
end

function sendZoneNotification(tNotify)
  if not GetAllZonesInProgress then
    NOTIFY.ZONE_CHANGED(tNotify)
  end
end

function sendChannelsNotification(tNotify)
  if GetAllChannelsInProgress then return end

  NOTIFY.CHANNELS_CHANGED(tNotify)
end

function sendChannelsNotificationFromMix(mixId)
  if GetAllChannelsInProgress then return end

  for zoneId = 1, NUM_ZONES do
    local zone = GetMixerZone(zoneId)
    local isActive = zone.is_active
    -- channel/mix has changed, need to rebuild UI...
    if isActive and (zone.source == mixId + 15) then
      local mixer_channels = GetMixerChannelsForUI(tonumber(zone.source)) or {}
      local tNotify = mixer_channels
      tNotify.RoomId = zone.room_id
      if tNotify.RoomId then
        NOTIFY.CHANNELS_CHANGED(tNotify)
      end
    end
  end
end

--[[=============================================================================
    Device Specific Command & Action Handlers
===============================================================================]]

function GetSourceConnId(source)
  if tonumber(source) == -1 then
    return -1
  else
    return tonumber(source) + 3001
  end
end

function GetSourcesList()
  MIXER_CHANNELS = MIXER_CHANNELS or {}
  MIXER_CHANNELS.Channels = MIXER_CHANNELS.Channels or {}
  local list = {}
  for _, v in pairs(MIXER_CHANNELS.Channels) do
    if v.is_active == true then
      table.insert(list, { text = v.name, value = v.id })
    end
  end

  MIXER_MIXES = MIXER_MIXES or {}
  MIXER_MIXES.Mixes = MIXER_MIXES.Mixes or {}
  for _, v in pairs(MIXER_MIXES.Mixes) do
    if v.is_active == true then
      local idSource = v.id + NUM_CHANNELS
      table.insert(list, { text = v.name, value = idSource })
    end
  end

  return list
end

function GetZonesList()
  MIXER_ZONES = MIXER_ZONES or {}
  MIXER_ZONES.Zones = MIXER_ZONES.Zones or {}
  local list = {}
  for _, v in pairs(MIXER_ZONES.Zones) do
    if v.is_active == true then
      table.insert(list, { text = v.name, value = v.id })
    end
  end

  return list
end

function GetMixesList()
  MIXER_MIXES = MIXER_MIXES or {}
  MIXER_MIXES.Mixes = MIXER_MIXES.Mixes or {}
  local list = {}
  for _, v in pairs(MIXER_MIXES.Mixes) do
    if v.is_active == true then
      table.insert(list, { text = v.name, value = v.id })
    end
  end

  return list
end

function EX_CMD.SelectZoneSource(tParams)
  local source = tonumber(tParams.Source)
  local zone = tonumber(tParams.Zone)
  SetZoneSelectedSource(zone, source)
end

function EX_CMD.SetRouting(tParams)
  local source = tonumber(tParams.Source)
  local zone = tonumber(tParams.Zone)
  SetZoneSelectedSource(zone, source)
end

function EX_CMD.SetMixChannelLevel(tParams)
  local mix = tonumber(tParams.Mix)
  local source = tonumber(tParams.Source)
  local level = tonumber(tParams.Level)
  SetMixChannelVolume(mix, source, level)
end

function EX_CMD.SetMixChannelMute(tParams)
  local mix = tonumber(tParams.Mix)
  local source = tonumber(tParams.Source)
  local mute = tParams.Mute -- ON | OFF
  local stringtoboolean={ ["ON"]=true, ["OFF"]=false }
  local isMuted = stringtoboolean[mute]
  SetMixChannelMute(mix, source, isMuted)
end

function EX_CMD.SetChannelLevel(tParams)
  local source = tonumber(tParams.Source)
  local level = tonumber(tParams.Level)
  SetSourceGain(source, level)
end

function EX_CMD.SetChannelMute(tParams)
  local source = tonumber(tParams.Source)
  local mute = tParams.Mute -- ON | OFF
  local stringtoboolean={ ["ON"]=true, ["OFF"]=false }
  local isMuted = stringtoboolean[mute]
  SetIsSourceMuted(source, isMuted)
end



--===============================================================================

function LUA_ACTION.SyncDriverWithMixer()
  SyncDriverWithMixer()
end

function SyncDriverWithMixer()
  -- Request configuration data from the mixer device...
  LogInfo("MIXER_CHANNELS: Get Mixer Channels Configuration From Mixer Not Implemented")	-- default
  LogInfo("MIXER_ZONES: Get Mixer Zones Configuration From Mixer Not Implemented")	-- default
  LogInfo("MIXER_MIXES: Get Mixer Mixes Configuration From Mixer Not Implemented")	-- default

end

function LUA_ACTION.PrintMixerC4ConnectionMap()
	--LogTrace(MIXER_CHANNELS.Channels)

	local printme = "------------ Mixer CHANNEL TO C4 CONNECTION MAP -------------\n"
	for _, channel in ipairs(MIXER_CHANNELS.Channels) do
		if toboolean(channel.is_active) then
			printme = printme .. channel.name .. " <<<<<>>>>> Source " .. channel.id .. "\n"
		end
	end
	printme = printme .. "---------------------------------------------\n"
	printme = printme .. "---------------------------------------------\n"

	printme = printme .. "------------ Mixer Zone TO C4 ROOM END-POINT CONNECTION MAP -------------\n"
	printme = printme .. "------------ [ Mixer Driver is the Audio Enpoint ] -------------\n"

	for _, zone in ipairs(MIXER_ZONES.Zones) do
		if toboolean(zone.is_active) then
			printme = printme .. zone.name .. " <<<<<>>>>> Room Selection - Zone " .. zone.id .. "\n"
		end
	end
	printme = printme .. "---------------------------------------------\n"

	printme = printme .. "------------ Mixer Zone TO Mixer Driver Output to Amp CONNECTION MAP -------------\n"
	printme = printme .. "------------ [ Amp Driver is the Audio Enpoint ] -------------\n"
	printme = printme .. "-- NOTE: Matrix switching amps are not supported. -------------\n"
	printme = printme ..
		"-- The Room Enpoint must correlate with the input (ie. Input 1 & Room Connection - Output 1, etc.) -------------\n"
	for _, zone in ipairs(MIXER_ZONES.Zones) do
		if toboolean(zone.is_active) then
			printme = printme ..
				zone.name ..
				" <<<<<>>>>> Zone " ..
				zone.id .. " <<<<<>>>>> Amp Input x " .. " <<<<<>>>>> Room Connection - Output x " .. "\n"
		end
	end
	printme = printme .. "---------------------------------------------\n"




	print(printme)
end
