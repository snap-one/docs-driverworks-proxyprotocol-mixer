function MixerCom_SetRouting(ZoneId, ChannelId, RoomId)
    LogTrace("MixerCom_SetRouting for Zone %s Channel %s", ZoneId, ChannelId)
    local zoneId = tonumber(ZoneId)
    local channelId = tonumber(ChannelId)
    local roomId = tonumber(RoomId)
    local sourceConnId = GetSourceConnIdFromRoomId(RoomId)

    LogInfo("Mixer Set Routing Not Implemented")	-- default

    local devProvider = C4:GetBoundProviderDevice(GetProxyID(MAIN_PROXY_BINDING_ID), 3000 + channelId)
    -- If channel is a mix, select mix no control driver if room has no selected source
    if IsMixConnection(sourceConnId) then
        local xml = C4:SendToDevice(MIXER_ZONES.Zones[zoneId].room_id, 'GET_CURRENT_AUDIO_SOURCE', {}) or ""
        local audioSource = string.match(xml, '<device>(.-)</device>')
        if audioSource then
            print(">>>>> Routing a Mix. Audio is currently playing, no source selection will be executed.")
        else
            print(">>>>> Routing a Mix. No Audio is currently playing, the Mix No Control driver will be selected.")
            MIXER_ZONES.Zones[zoneId].source = channelId - 1
            MIXER_ZONES.Zones[zoneId].sourceConnId = GetSourceConnId(MIXER_ZONES.Zones[zoneId].source)
            C4:SendToDevice(roomId, 'SELECT_AUDIO_DEVICE', { deviceid = devProvider })
        end
        return
    end

    LogTrace("Routing: There is device connected to this input, starting it...")
    MIXER_ZONES.Zones[zoneId].source = channelId - 1
    MIXER_ZONES.Zones[zoneId].sourceConnId = GetSourceConnId(MIXER_ZONES.Zones[zoneId].source)
    local tag = C4:GetDeviceDisplayName(devProvider)
    MIXER_CHANNELS.Channels[channelId].source_label_tag = tag

    C4:SendToDevice(roomId, 'SELECT_AUDIO_DEVICE', { deviceid = devProvider })

    PersistData.MIXER_ZONES = MIXER_ZONES
    PersistData.MIXER_CHANNELS = MIXER_CHANNELS
end

function GetSourceIdFromRoomId(room_id)
    local output_id = GetAudioProviderOutputIdFromRoomId(room_id)

    -- zone ouput connection ids start at 7000...
    local zoneId = tonumber(output_id) % 1000 + 1
    local zone = GetMixerZone(zoneId)
    local sourceId = zone.source

    return sourceId
end

function GetSourceConnIdFromRoomId(room_id)
    local output_id = GetAudioProviderOutputIdFromRoomId(room_id)

    -- zone ouput connection ids start at 7000...
    local zoneId = tonumber(output_id) % 1000 + 1
    local zone = GetMixerZone(zoneId)
    local sourceConnId = zone.sourceConnId

    return sourceConnId
end

function MixerCom_SetChannelInputLevel(ChannelId, Level, RoomId)
    LogTrace("MixerCom_SetChannelInputLevel for Channel %s -> %s", ChannelId, Level)

    local sourceConnId = GetSourceConnIdFromRoomId(RoomId)

    if IsMixConnection(sourceConnId) then
        local mixId = GetMixId(sourceConnId)
        LogInfo("Mixer Set Mix Channel Level Not Implemented")	-- default
    else
        LogInfo("Mixer Set Channel Level Not Implemented")	-- default
    end
end

function MixerCom_SetChannelMuted(ChannelId, Muted, RoomId)
    LogTrace("MixerCom_SetChannelMuted for Channel %s -> %s", ChannelId, Muted)

    local sourceConnId = GetSourceConnIdFromRoomId(RoomId)

    if IsMixConnection(sourceConnId) then
        local mixId = GetMixId(sourceConnId)
        LogInfo("Mixer Set Mix Channel Mute Not Implemented")	-- default
    else
        LogInfo("Mixer Set Channel Mute Not Implemented")	-- default
    end
end

function MixerCom_SetEqEnabled(ChannelId, Enabled)
    LogTrace("MixerCom_SetEqEnabled for Channel %s -> %s", ChannelId, Enabled)
    LogInfo("Mixer Set Channel EQ Enabled Not Implemented")	-- default
end

function MixerCom_SetCompressorEnabled(ChannelId, Enabled)
    LogTrace("MixerCom_SetCompressorEnabled for Channel %s -> %s", ChannelId, Enabled)
    LogInfo("Mixer Set Channel Compressor Enabled Not Implemented")	-- default
end

function MixerCom_SetDeEsserEnabled(ChannelId, Enabled)
    LogTrace("MixerCom_SetDeEsserEnabled for Channel %s -> %s", ChannelId, Enabled)
    LogInfo("Mixer Set Channel De-Esser Enabled Not Implemented")	-- default
end

function MixerCom_SetNoiseGateEnabled(ChannelId, Enabled)
    LogTrace("MixerCom_SetNoiseGateEnabled for Channel %s -> %s", ChannelId, Enabled)
    LogInfo("Mixer Set Channel Noise Gate Enabled Not Implemented")	-- default
end

function MixerCom_SetEqBandEnabled(ChannelId, BandId, Enabled)
    LogTrace("MixerCom_SetEqBandEnabled for Channel %s Band %s -> %s", ChannelId, BandId, Enabled)
    LogInfo("Mixer Set Channel EQ Band Enabled Not Implemented")	-- default
end

function MixerCom_SetEqBandGainLevel(ChannelId, BandId, Level)
    LogTrace("MixerCom_SetEqBandGainLevel for Channel %s Band %s -> %s", ChannelId, BandId, Level)
    LogInfo("Mixer Set Channel EQ Band Gain Not Implemented")	-- default
end

function MixerCom_SetEqBandQLevel(ChannelId, BandId, Q)
    LogTrace("MixerCom_MixerCom_SetEqBandQLevel for Channel %s Band %s -> %s", ChannelId, BandId, Level)
    LogInfo("Mixer Set Channel EQ Band Q Not Implemented")	-- default
end

function MixerCom_SetEqBandFrequency(ChannelId, BandId, Frequency)
    LogTrace("MixerCom_SetEqBandFrequency for Channel %s Band %s -> %s", ChannelId, BandId, Frequency)
    LogInfo("Mixer Set Channel EQ Band Frequency Not Implemented")	-- default
end

--[[ 
    Compressor Components:
    The number and name of Compressor Components are dynamic within each driver.
    Each Components will have a unique Key which is also the name of the Component.
    These Components are defined during the initial data sync with the device.
    Subsequent Commands and Notification will uses the Keys established in the initial sync.
    The Keys in the function below are only examples of typical Keys; you must modify the function for your device configuration.
]]
function MixerCom_SetCompressorComponentValue(ChannelId, Key, Value)
    LogTrace("MixerCom_SetCompressorComponentValue for Channel %s Key %s -> %s", ChannelId, Key, Value)

    if Key == "threshold" then
        local threshold = tonumber(Value)
        LogInfo("Mixer Set Channel Compressor Threshold Not Implemented")	-- default
    elseif Key == "ratio" then
        local ratio = tonumber(Value)
        LogInfo("Mixer Set Channel Compressor Ratio Not Implemented")	-- default
    elseif Key == "attack" then
        local attack = tonumber(Value)
        LogInfo("Mixer Set Channel Compressor Attack Not Implemented")	-- default
    elseif Key == "release" then
        local release = tonumber(Value)
        LogInfo("Mixer Set Channel Compressor Release Not Implemented")	-- default
    elseif Key == "makeUp" then
        local makeUp = tonumber(Value)
        LogInfo("Mixer Set Channel Compressor MakeUp Not Implemented")	-- default
    end
end

--[[ 
    De-Esser Components:
    The number and name of De-Esser Components are dynamic within each driver.
    Each Components will have a unique Key which is also the name of the Component.
    These Components are defined during the initial data sync with the device.
    Subsequent Commands and Notification will uses the Keys established in the initial sync.
    The Keys in the function below are only examples of typical Keys; you must modify the function for your device configuration.
]]
function MixerCom_SetDeEsserComponentValue(ChannelId, Key, Value)
    LogTrace("MixerCom_SetDeEsserComponentValue for Channel %s Key %s -> %s", ChannelId, Key, Value)

    if Key == "frequency" then
        local frequency = tonumber(Value)
        LogInfo("Mixer Set Channel De-Esser Frequency Not Implemented")	-- default
    elseif Key == "sensitivity" then
        local sensitivity = tonumber(Value)
        LogInfo("Mixer Set Channel De-Esser Sensitivity Not Implemented")	-- default
    elseif Key == "selectivity" then
        local selectivity = tonumber(Value)
        LogInfo("Mixer Set Channel De-Esser Selectivity Not Implemented")	-- default
    elseif Key == "reduction" then
        local reduction = tonumber(Value)
        LogInfo("Mixer Set Channel De-Esser Reduction Not Implemented")	-- default
    end
end

--[[ 
    Noise Gate Components:
    The number and name of Noise Gate Components are dynamic within each driver.
    Each Components will have a unique Key which is also the name of the Component.
    These Components are defined during the initial data sync with the device.
    Subsequent Commands and Notification will uses the Keys established in the initial sync.
    The Keys in the function below are only examples of typical Keys; you must modify the function for your device configuration.
]]
function MixerCom_SetNoiseGateComponentValue(ChannelId, Key, Value)
    LogTrace("MixerCom_SetNoiseGateComponentValue for Channel %s Key %s -> %s", ChannelId, Key, Value)

    if Key == "threshold" then
        local threshold = tonumber(Value)
        LogInfo("Mixer Set Channel Noise Gate Threshold Not Implemented")	-- default
    elseif Key == "attack" then
        local attack = tonumber(Value)
        LogInfo("Mixer Set Channel Noise Gate Attack Not Implemented")	-- default
    elseif Key == "release" then
        local release = tonumber(Value)
        LogInfo("Mixer Set Channel Noise Gate Release Not Implemented")	-- default
    elseif Key == "hold" then
        local hold = tonumber(Value)
        LogInfo("Mixer Set Channel Noise Gate Hold Not Implemented")	-- default
    end
end