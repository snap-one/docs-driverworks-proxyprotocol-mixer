--[[=============================================================================
    Notification Functions sent to the AVSwitch proxy from the driver

    Copyright 2025 Snap One, LLC. All Rights Reserved.
===============================================================================]]

require "common.c4_notify"

-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.avswitch_proxy_notifies = "2025.07.14"
end

function NOTIFY.CHANNELS_INIT(Params, BindingID) --MIXER_CHANNELS
    SendNotifyToMixerProxy('CHANNELS_INIT', Params, BindingID)
end

function NOTIFY.ZONES_INIT(Params, BindingID)  --MIXER_ZONES
    SendNotifyToMixerProxy('ZONES_INIT', Params, BindingID)
end

function NOTIFY.MIXER_CONNECTIONS_INIT(Params, BindingID)  --MIXER_CONNECTIONS
    SendNotifyToMixerProxy('MIXER_CONNECTIONS_INIT', Params, BindingID)
end

function NOTIFY.MIXES_INIT(Params, BindingID)  --MIXER_MIXES
    SendNotifyToMixerProxy('MIXES_INIT', Params, BindingID)
end

function NOTIFY.CHANNELS_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('CHANNELS_CHANGED', Params, BindingID)
end

function NOTIFY.CHANNEL_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('CHANNEL_CHANGED', Params, BindingID)
end

function NOTIFY.MIX_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('MIX_CHANGED', Params, BindingID)
end

function NOTIFY.ZONES_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('ZONES_CHANGED', Params, BindingID)
end

function NOTIFY.ZONE_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('ZONE_CHANGED', Params, BindingID)
end

function NOTIFY.ZONE_SOURCE_CHANGED(Params, BindingID)
    SendNotifyToMixerProxy('ZONE_SOURCE_CHANGED', Params, BindingID)
end

function SendNotifyToMixerProxy(sNotify, Params, BindingID)
    LogTrace("SendNotifyToMixerProxy: " .. sNotify)
    LogTrace(Params)

    local params = C4:JsonEncode(Params, false, true)
    local tParams = {
        param = params
    }

    SendNotify(sNotify, tParams, BindingID)
end