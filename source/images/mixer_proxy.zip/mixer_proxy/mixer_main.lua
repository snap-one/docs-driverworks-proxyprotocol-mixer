--[[=============================================================================
    File is: mixer_main.lua

    Copyright 2025 Snap One, LLC. All Rights Reserved.
===============================================================================]]

require "mixer_proxy.mixer_device_class"
require "mixer_proxy.mixer_reports"
require "mixer_proxy.mixer_apis"
require "mixer_proxy.c4_path_utils"
require "mixer_communicator"	

-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.mixer_main = "2025.03.11"
end

TheMixer = nil		-- can only have one Mixer in a driver

function CreateMixerProxy(BindingID, ProxyInstanceName)
	if(TheMixer == nil) then
		TheMixer = MixerDevice:new(BindingID, ProxyInstanceName)

		if(TheMixer ~= nil) then
			TheMixer:InitialSetup()
		else
			LogFatal("CreateMixerProxy  Failed to instantiate Mixer")
		end
	end
end

--========================================================
-- Common property change routines
