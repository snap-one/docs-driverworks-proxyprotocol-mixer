## README
Mixer Proxy Driver Development Documentation

**_Note:_**
This documentation is focused specifically on the Mixer Proxy Driver Development Template. If you are new to driver development templates, it is recommended reviewing the files and associated README content found in the template repository prior to beginning your driver development efforts:

[https://github.com/snap-one/drivers-template-code-public/tree/release](https://github.com/snap-one/drivers-template-code-public/tree/release)

### Introduction
Use of the Mixer Proxy Driver Development Template assumes understanding the Mixer Proxy.

The Mixer proxy is intended to be used in conjunction with the [AV Switch proxy](https://snap-one.github.io/docs-driverworks-proxyprotocol-avswitch/#license-copyright-and-trademark). The AV Switch proxy handles all the typical AV Switch functions such as input/output selection, room/zone volume control, etc. The Mixer proxy extends this functionality to support Mixer channel volume/mute control as well as Digital Signal Processing (DSP). 

In addition to the normal AV Switch constructs of Inputs, Outputs and Selected Source the Mixer proxy adds Channels, Zones and Mixes. Channels also support advanced DSP signal processing including EQ, Compression, De-Essing and Noise Gate.

AV Pathing and Source selection are at the heart of most AV proxies and the Mixer proxy is no different. However, since the Mixer proxy is designed to extend the AV Switch proxy, some of these lines do get blurred. For example, a CD player bound to an input of the protocol driver is part of the AV Switch pathing logic but it is also a channel of the Mixer and as such can be part of a Mix.

Furthermore, it may be desired to start an audio session by just selecting a Mix of channels and not have a particular selected (controllable) source. Or the user may wish to select a single microphone (not controllable) as the selected source. To handle these use cases, No Control drivers have been created for both Microphone and Mix.

Since Mixes and Channels require different handling logic, the Mixer proxy must know if the selected source is a Channel or a Mix. To support this functionality, special mixId and channelId elements must be included in the appropriate Input Connections in the protocol driver. Using this modeling, the Proxy maintains a map of all connections with this data in the MIXER\_CONNECTIONS table.

Note that Mixer Connections have special connection elements:

- Channel Connections shall include a channelid (integer) element

```xml
<connection proxybindingid="5001">
    <id>3001</id>
    <facing>1</facing>
    <connectionname>Channel 1</connectionname>
    <type>6</type>
    <consumer>True</consumer>
    <audiosource>False</audiosource>
    <videosource>False</videosource>
    <linelevel>True</linelevel>
    <channelid>1</channelid>
    <classes>
    <class>
        <classname>STEREO</classname>
    </class>
    </classes>
</connection>
```

- Mix Connections shall include a mixid (integer) element

```xml
<connection proxybindingid="5001">
    <id>3009</id>
    <facing>1</facing>
    <connectionname>Mix 1</connectionname>
    <type>6</type>
    <consumer>True</consumer>
    <audiosource>False</audiosource>
    <videosource>False</videosource>
    <linelevel>True</linelevel>
    <mixid>1</mixid>
    <classes>
    <class>
        <classname>STEREO</classname>
    </class>
    </classes>
</connection>
```

An important distinction (and possible source of confusion) is how the UI and Proxy handle Input Channel Volume. As in the case of actual mixer devices, an input channel has a level (volume) control which will affect the signal before any further modification of that channel in a mix. For example, if a device can create more than one mix, changing the input channel volume will affect the level of that channel in all mixes. Whereas changing the volume of that channel in a mix will only affect the level of that channel in that mix. While this is a straightforward concept, it does get clouded by Control4 source selection and control logic in conjunction with the fact that the mixer proxy is the first AV Proxy that handles volume control of an input (Room volume control adjusts the volume of an output/zone in a device). To simplify user interaction, it has been decided that, from a Control4 perspective, Input Channel Level will be a configuration element and not supported via the Control4 UI. So, when a Source is selected, the level control is visible but grayed out and not available for modification. When a Mix is selected, all Channels are available for modification in that Mix.

Documentation defining the functionality supported through the Mixer Proxy can be found here: [https://snap-one.github.io/docs-driverworks-proxyprotocol-mixer/#what-s-new](https://snap-one.github.io/docs-driverworks-proxyprotocol-mixer/#what-s-new)

### device\_specific.lua

This .lua file contains utility functions that assist with handling binary code, parsing string, table management, etc. You’l note that the device\_specific.lua file is located in the Modify directory. This indicates that this file requires modification by the driver developer.

The area of the file requiring modification is found under the Driver Template Functions section. Specifically, the functions supporting message handling from the mixer device to the Mixer Proxy need to be reviewed.

You’ll find that these messages are handled by the function HandleMessage or `function HandleMessage(message)`

The HandleMessage function includes all of the functions supported by the Mixer Proxy as well as their parameters. As a driver developer you have two options:

1. Modify the template’s message structure to match your device’s messaging.
2. Map your device’s message structure to match those found under HandleMessage.

For example, the function for changing a channel’s gain level is called: CHANNEL\_GAIN. You can see the message handler for a channel gain change in the following code:

`DEV_MSG.CHANNEL_GAIN({channelId = channelId, gain = message.payload})`

Note that every message has the following:

- message.type
- payload.type
- payload

Regardless of which method you choose, the message must contain those values.

Consider that your device sends channel gain changes using a hex string that look something like this: `AAAAFFCC0050`

In our example, the first 4 hex values (`AAAA`) indicate that this is a 'channel' message or message.type in the template.

The next 4 hex values (`FFCC`) indicate this is a 'channel gain' message or payload.type in the template.

The next 4 hex values (`0050`) represent the new 'channel gain value' or payload in the template. 

As a driver writer, you would need to create a handler function that will parse the response from your device and call HandleMessage with a properly formatted message table parameter. For example:

```lua
function GetMessage(response)
    local messageType, payloadType, payload = string.match(response, "(....)(....)(....)")
    local tMessage = {}

    if messageType == "AAAA" then
        tMessage.messageType = "channel"
        if payloadType == "FFCC" then
            tMessage.payloadType = "channel_gain"
        else
            -- TODO: complete elseif blocks for remainder of payloadTypes
        end
    elseif messageType == "BBBB" then
        tMessage.messageType = "channel_eq"
        if payloadType == "FFCC" then
            tMessage.payloadType = "eq_band_gain"
        else
            -- TODO: complete elseif blocks for remainder of payloadTypes
        end
    else
        -- TODO: complete elseif blocks for remainder of messageTypes
    end

    tMessage.payload = payload

    HandleMessage(tMessage)
end
```

The goal of the template, and in this case the HandleMessage function, is to ease your driver development efforts. If you format your devices messages correctly, the HandleMessage function will parse the message coming in and pass that data to the appropriate function defined lower in the device\_specific.lua file. At this point:

1. The data is updated in the global data structures that are maintained for the use of the Mixer Proxy.
2. A notification is send from the Mixer Proxy to the device.
3. The data is then persisted.

### mixer\_communicator.lua

In order to understand the role of the mixer\_communicator.lua file, it is worth reviewing a driver development template construct used when handling proxy commands. For every command defined in the template’s mixer\_proxy\_commands.lua file a handler command exists in the mixer\_device\_class.lua file.

When a command is passed from the mixer\_proxy\_commands.lua file to the mixer\_device\_class.lua file, the appropriate handler command performs any parsing of the command data and then sends it to the mixer\_communicator .lua file.

_Note that as a driver developer using the template, you will not need to modify any content in the mixer\_proxy\_commands.lua file or the mixer\_device\_class.lua file. _

For example, the mixer\_communicator.lua file contains a function called MixerCom\_SetEqEnabled:

```lua
function MixerCom_SetEqEnabled(ChannelId, Enabled)
LogTrace("MixerCom_SetEqEnabled for Channel %s -> %s", ChannelId, Enabled)
LogInfo("Mixer Set Channel EQ Enabled Not Implemented")	-- default
end
```

This function is used to enable or disable an EQ for a channel. It requires two parameters: and Channel ID and a boolean parameter if the EQ is enabled or disabled.

Note the LogInfo line. This is a note for you (the driver developer) to indicate that this has not yet been implemented. Here you will need to define your handler function that will enable or disable an EQ for a channel that is specific to your device. 

The mixer\_communicator.lua file also contain two channel specific functions:

- MixerCom\_SetChannelInputlevel
- MixerCom\_SetChannelMuted

Channels are handled in the Control4 UI in two manners:

An individual Channel - This represents the actual channel strip on a mixer. If a change is made to this channel, any mix including this channel is affected.
or
An array of channels that comprise a Mix.

This construct is worth noting. For example, when a Channel Input Level is received (`MixerCom_SetChannelInputlevel`) it could be for a unique channel strip or for channel within a mix.

The template handles this by providing two LogInfo entries:

1. `LogInfo("Mixer Set Channel Level Not Implemented") -- default`

This indicates that the input level change is for an individual channel. This where you as a driver developer will need to define a handler command for changing the input level for a single channel on your device.

2. `LogInfo("Mixer Set Mix Channel Level Not Implemented") -- default`

This indicates that the input level change is for a channel within a mix. This where you as a driver developer will need to define a handler command for changing the input level found within a mix on your device.

Routing is also handled within the mixer\_communicator.lua file. Routing defines what channels are routed to a mixer output or zone. This is accomplished with the MixerCom\_SetRouting function. Within the function. you’ll note:

`LogInfo("Mixer Set Routing Not Implemented") -- default`

This is where you as a driver developer will need to define a routing handler function for your device.

Note the SELECT\_AUDIO\_DEVICE function that is defined within the MixerCom\_SetRouting function. This function support a user experience where a channel is selected from the routing page in the UI, the appropriate device will be selected if that device is bound to the channel.

### Data Structures

** Data table default definitions can be found in device\_specific.lua

These tables should be intialized from the LUA_ACTION.SyncDriverWithMixer() function:

- MIXER_CHANNELS

- MIXER_ZONES

- MIXER_MIXES

The MIXER_CONNECTIONS table is built in GetMixerConnections() by parsing the connections xml in driver.xml. This function is called in ON_DRIVER_LATEINIT.MixerLateInit():

- MIXER_CONNECTIONS
