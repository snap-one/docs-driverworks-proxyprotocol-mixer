--[[===========================================================================
    Command Functions Received From Mixer Proxy to the Driver

    Copyright 2025 Snap One, LLC. All Rights Reserved.
===============================================================================]]

require "lib.c4_log"

-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.avswitch_proxy_commands = "2025.03.11"
end

--[[============================================================================
    Commands
================================================================================]]


function PRX_CMD.SET_ROUTING(idBinding, tParams)
    LogTrace("PRX_CMD.SET_ROUTING")
	ProxyInstance(idBinding):PrxSetRouting(tParams)
end

function PRX_CMD.SET_CHANNEL_INPUT_LEVEL(idBinding, tParams)
    LogTrace("PRX_CMD.SET_CHANNEL_INPUT_LEVEL")

    ProxyInstance(idBinding):PrxSetChannelInputLevel(tParams)
end

--SET_CHANNEL_MUTED(roomId: Long, channelId: Int, muted: Boolean) 
function PRX_CMD.SET_CHANNEL_MUTED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_CHANNEL_MUTED")

    ProxyInstance(idBinding):PrxSetChannelMuted(tParams)
end


--SET_EQ_ENABLED(roomId: Long, channelId: Int, enabled: Boolean)
function PRX_CMD.SET_EQ_ENABLED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_EQ_ENABLED")

    ProxyInstance(idBinding):PrxSetEqEnabled(tParams)
end

--SET_COMPRESSOR_ENABLED(roomId: Long, channelId: Int, enabled: Boolean)
function PRX_CMD.SET_COMPRESSOR_ENABLED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_COMPRESSOR_ENABLED")

    ProxyInstance(idBinding):PrxSetCompressorEnabled(tParams)
end

--SET_DE_ESSER_ENABLED(roomId: Long, channelId: Int, enabled: Boolean)
function PRX_CMD.SET_DE_ESSER_ENABLED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_DE_ESSER_ENABLED")

    ProxyInstance(idBinding):PrxSetDeEsserEnabled(tParams)
end

--SET_NOISE_GATE_ENABLED(roomId: Long, channelId: Int, enabled: Boolean) 
function PRX_CMD.SET_NOISE_GATE_ENABLED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_NOISE_GATE_ENABLED")

    ProxyInstance(idBinding):PrxSetNoiseGateEnabled(tParams)
end

--SET_EQ_BAND_ENABLED(roomId: Long, channelId: Int, bandId: Int, enabled: Boolean)
function PRX_CMD.SET_EQ_BAND_ENABLED(idBinding, tParams)
    LogTrace("PRX_CMD.SET_EQ_BAND_ENABLED")

    ProxyInstance(idBinding):PrxSetEqBandEnabled(tParams)
end

--SET_EQ_BAND_GAIN_LEVEL(roomId: Long, channelId: Int, bandId: Int, level: Float)
function PRX_CMD.SET_EQ_BAND_GAIN_LEVEL(idBinding, tParams)
    LogTrace("PRX_CMD.SET_EQ_BAND_GAIN_LEVEL")

    ProxyInstance(idBinding):PrxSetEqBandGainLevel(tParams)
end

--SET_EQ_BAND_Q_LEVEL(roomId: Long, channelId: Int, bandId: Int, level: Float)
function PRX_CMD.SET_EQ_BAND_Q_LEVEL(idBinding, tParams)
    LogTrace("PRX_CMD.SET_EQ_BAND_Q_LEVEL")

    ProxyInstance(idBinding):PrxSetEqBandQLevel(tParams)
end

--SET_EQ_BAND_FREQUENCY(roomId: Long, channelId: Int, bandId: Int, frequency: Int)
function PRX_CMD.SET_EQ_BAND_FREQUENCY(idBinding, tParams)
    LogTrace("PRX_CMD.SET_EQ_BAND_FREQUENCY")

    ProxyInstance(idBinding):PrxSetEqBandFrequency(tParams)
end

--SET_COMPRESSOR_COMPONENT_VALUE(roomId: Long, channelId: Int, key: String, value: Float)
function PRX_CMD.SET_COMPRESSOR_COMPONENT_VALUE(idBinding, tParams)
    LogTrace("PRX_CMD.SET_COMPRESSOR_COMPONENT_VALUE")

    ProxyInstance(idBinding):PrxSetCompressorComponentValue(tParams)
end

--SET_DE_ESSER_COMPONENT_VALUE(roomId: Long, channelId: Int, key: String, value: Float)
function PRX_CMD.SET_DE_ESSER_COMPONENT_VALUE(idBinding, tParams)
    LogTrace("PRX_CMD.SET_DE_ESSER_COMPONENT_VALUE")

    ProxyInstance(idBinding):PrxSetDeEsserComponentValue(tParams)
end

--SET_NOISE_GATE_COMPONENT_VALUE(roomId: Long, channelId: Int, key: String, value: Float)
function PRX_CMD.SET_NOISE_GATE_COMPONENT_VALUE(idBinding, tParams)
    LogTrace("PRX_CMD.SET_NOISE_GATE_COMPONENT_VALUE")

    ProxyInstance(idBinding):PrxSetNoiseGateComponentValue(tParams)
end

--=============================================================================
--=============================================================================

function UI_REQ.GET_ALL_AUDIO_MIXER_CHANNELS(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAllAudioMixerChannels(tParams)
	else
		LogError("UI_REQ.GET_ALL_AUDIO_MIXER_CHANNELS  Mixer not defined")
		return ""
	end
end

function UI_REQ.GET_AUDIO_MIXER_CHANNELS(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAudioMixerChannels(tParams)
	else
		LogError("UI_REQ.GET_AUDIO_MIXER_CHANNELS  Mixer not defined")
		return ""
	end
end

function UI_REQ.GET_AUDIO_MIXER_CHANNEL(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAudioMixerChannel(tParams)
	else
		LogError("UI_REQ.GET_AUDIO_MIXER_CHANNEL  Mixer not defined")
		return ""
	end
end

function UI_REQ.GET_AUDIO_MIXER_ZONES(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAudioMixerZones(tParams)
	else
		LogError("UI_REQ.GET_AUDIO_MIXER_ZONES  Mixer not defined")
		return ""
	end
end

function UI_REQ.GET_AUDIO_MIXER_ZONE(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAudioMixerZone(tParams)
	else
		LogError("UI_REQ.GET_AUDIO_MIXER_ZONE  Mixer not defined")
		return ""
	end
end

function UI_REQ.GET_AUDIO_MIXER_ZONE_SOURCES(tParams)
	if (TheMixer) then
		return TheMixer:ReqGetAudioMixerZoneSources(tParams)
	else
		LogError("UI_REQ.GET_AUDIO_MIXER_ZONE_SOURCES  Mixer not defined")
		return ""
	end
end