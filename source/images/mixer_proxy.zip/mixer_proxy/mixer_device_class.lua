--[[=============================================================================
    Mixer Device Class

    Copyright 2025 Snap One, LLC. All Rights Reserved.
===============================================================================]]

require "common.c4_utils"
require "lib.c4_proxybase"
require "lib.c4_log"
require "mixer_proxy.mixer_proxy_commands"
require "mixer_proxy.mixer_proxy_notifies"
require "modules.c4_metrics"


-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.avswitch_device_class = "2025.03.11"
end


MixerDevice = inheritsFrom(C4ProxyBase)

--[[=============================================================================
    Functions that are meant to be private to the class
===============================================================================]]
function MixerDevice:construct(BindingID, InstanceName)
	self:super():construct(BindingID, self, InstanceName)

	self._PowerOn = false
	self._PersistData = nil
	self._ChannelsByBinding = {}
	self._ChannelsByName = {}
	self._NumChannels = 0
	self._NumZones = 0

	-- first one in gets to be the default
	if(MixerDevice.DefaultProxyName == "") then
		MixerDevice.DefaultProxyName = self:GetProxyName()
	end
end


----------------------


----------------------

function MixerDevice:InitialSetup()
	if(PersistData.MixerPersist == nil) then
		PersistData.MixerPersist = {}
	end
end

-------------

--=============================================================================
--=============================================================================

function MixerDevice:PrxSetRouting(tParams)
	LogTrace("MixerDevice:PrxSetRouting")
	MixerCom_SetRouting(tParams)
end

function MixerDevice:PrxSetChannelInputLevel(tParams)
	LogTrace("MixerDevice:PrxSetChannelInputLevel")
	local RoomId = tonumber(tParams.roomId)
    local ChannelId = tonumber(tParams.channelId)
    local Level = tonumber(tParams.level)

	MixerCom_SetChannelInputLevel(ChannelId, Level, RoomId)
end

function MixerDevice:PrxSetChannelMuted(tParams)
	LogTrace("MixerDevice:PrxSetChannelMuted")
    local RoomId = tonumber(tParams.roomId)
    local ChannelId = tonumber(tParams.channelId)
    local Muted = toboolean(tParams.muted)

	MixerCom_SetChannelMuted(ChannelId, Muted, RoomId)
end

function MixerDevice:PrxSetEqEnabled(tParams)
	LogTrace("MixerDevice:PrxSetEqEnabled")
    local ChannelId = tonumber(tParams.channelId)
    local Enabled = toboolean(tParams.enabled)

	MixerCom_SetEqEnabled(ChannelId, Enabled)
end

function MixerDevice:PrxSetCompressorEnabled(tParams)
	LogTrace("MixerDevice:PrxSetCompressorEnabled")
    local ChannelId = tonumber(tParams.channelId)
    local Enabled = toboolean(tParams.enabled)

	MixerCom_SetCompressorEnabled(ChannelId, Enabled)
end

function MixerDevice:PrxSetDeEsserEnabled(tParams)
	LogTrace("MixerDevice:PrxSetDeEsserEnabled")
    local ChannelId = tonumber(tParams.channelId)
    local Enabled = toboolean(tParams.enabled)

	MixerCom_SetDeEsserEnabled(ChannelId, Enabled)
end

function MixerDevice:PrxSetNoiseGateEnabled(tParams)
	LogTrace("MixerDevice:PrxSetNoiseGateEnabled")
    local ChannelId = tonumber(tParams.channelId)
    local Enabled = toboolean(tParams.enabled)

	MixerCom_SetNoiseGateEnabled(ChannelId, Enabled)
end

function MixerDevice:PrxSetEqBandEnabled(tParams)
	LogTrace("MixerDevice:PrxSetEqBandEnabled")
    local ChannelId = tonumber(tParams.channelId)
    local BandId = tonumber(tParams.bandId)
    local Enabled = toboolean(tParams.enabled)

	MixerCom_SetEqBandEnabled(ChannelId, BandId, Enabled)
end

function MixerDevice:PrxSetEqBandGainLevel(tParams)
	LogTrace("MixerDevice:PrxSetEqBandGainLevel")
    local ChannelId = tonumber(tParams.channelId)
    local BandId = tonumber(tParams.bandId)
    local Level = tonumber(tParams.level)

	MixerCom_SetEqBandGainLevel(ChannelId, BandId, Level)
end

function MixerDevice:PrxSetEqBandQLevel(tParams)
	LogTrace("MixerDevice:PrxSetEqBandQLevel")
    local ChannelId = tonumber(tParams.channelId)
    local BandId = tonumber(tParams.bandId)
    local Q = tonumber(tParams.q)

	MixerCom_SetEqBandQLevel(ChannelId, BandId, Q)
end

function MixerDevice:PrxSetEqBandFrequency(tParams)
	LogTrace("MixerDevice:PrxSetEqBandFrequency")
    local ChannelId = tonumber(tParams.channelId)
    local BandId = tonumber(tParams.bandId)
    local Frequency = tonumber(tParams.frequency)

	MixerCom_SetEqBandFrequency(ChannelId, BandId, Frequency)
end

function MixerDevice:PrxSetCompressorComponentValue(tParams)
	LogTrace("MixerDevice:PrxSetCompressorComponentValue")
    local ChannelId = tonumber(tParams.channelId)
    local Key = tParams.key
    local Value = tParams.value

	MixerCom_SetCompressorComponentValue(ChannelId, Key, Value)
end

function MixerDevice:PrxSetDeEsserComponentValue(tParams)
	LogTrace("MixerDevice:PrxSetDeEsserComponentValue")
    local ChannelId = tonumber(tParams.channelId)
    local Key = tParams.key
    local Value = tParams.value

	MixerCom_SetDeEsserComponentValue(ChannelId, Key, Value)
end

function MixerDevice:PrxSetNoiseGateComponentValue(tParams)
	LogTrace("MixerDevice:PrxSetNoiseGateComponentValue")
    local ChannelId = tonumber(tParams.channelId)
    local Key = tParams.key
    local Value = tParams.value
	
	MixerCom_SetNoiseGateComponentValue(ChannelId, Key, Value)
end


--=============================================================================
--=============================================================================

function MixerDevice:InitChannels(Params)
	NOTIFY.CHANNELS_INIT(Params, self._Parent:GetBindingID())
end

function MixerDevice:InitZones(Params)
	NOTIFY.ZONES_INIT(Params, self._Parent:GetBindingID())
end

function MixerDevice:InitMixerConnections(Params)
	NOTIFY.MIXER_CONNECTIONS_INIT(Params, self._Parent:GetBindingID())
end

function MixerDevice:InitMixes(Params)
	NOTIFY.MIXES_INIT(Params, self._Parent:GetBindingID())
end

function MixerDevice:ChannelsChanged(Params)
	NOTIFY.CHANNELS_CHANGED(Params, self._Parent:GetBindingID())
end

function MixerDevice:ChannelChanged(Params)
	NOTIFY.CHANNEL_CHANGED(Params, self._Parent:GetBindingID())
end

function MixerDevice:ZonesChanged(Params)
	NOTIFY.ZONES_CHANGED(Params, self._Parent:GetBindingID())
end

function MixerDevice:ZoneChanged(Params)
	NOTIFY.ZONE_CHANGED(Params, self._Parent:GetBindingID())
end

function MixerDevice:ZoneSourceChanged(Params)
	NOTIFY.ZONE_SOURCE_CHANGED(Params, self._Parent:GetBindingID())
end