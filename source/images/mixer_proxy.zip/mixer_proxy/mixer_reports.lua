--[[=============================================================================
    File is: receiver_reports.lua

    Copyright 2025 Snap One LLC. All Rights Reserved.
	
	Routines to report information that we have received from the device.
===============================================================================]]

-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.avswitch_reports = "2025.02.25"
end


---------------------------------------------------------------------------------------

function MixerReport_InitChannels(Params) --MIXER_CHANNELS
	TheMixer:InitChannels(Params)
end

function MixerReport_InitZones(Params)  --MIXER_ZONES
	TheMixer:InitZones(Params)
end

function MixerReport_InitMixerConnections(Params)  --MIXER_CONNECTIONS
	TheMixer:InitMixerConnections(Params)
end

function MixerReport_InitMixes(Params)  --MIXER_MIXES
	TheMixer:InitMixes(Params)
end

function MixerReport_ChannelsChanged(Params)
	TheMixer:ChannelsChanged(Params)
end

function MixerReport_ChannelChanged(Params)
	TheMixer:ChannelChanged(Params)
end

function MixerReport_ZonesChanged(Params)
	TheMixer:ZonesChanged(Params)
end

function MixerReport_ZoneChanged(Params)
	TheMixer:ZoneChanged(Params)
end

function MixerReport_ZoneSourceChanged(Params)
	TheMixer:ZoneSourceChanged(Params)
end

--[[
function AVSwitchReport_PowerState(IsOn)
	TheMixer:PowerSetting(IsOn)
end

function AVSwitchReport_InputOutputChanged(OutputName, InputName, IsAudio, IsVideo)
	TheMixer:AssignInputOutput(OutputName, InputName, IsAudio, IsVideo)
end

function AVSwitchReport_OutputDisconnected(OutputName, IsAudio, IsVideo)
	TheMixer:AssignInputOutput(OutputName, "", IsAudio, IsVideo)
end


function AVSwitchReport_VolumeLevel(OutputName, VolLevel)
	TheMixer:SetVolumeLevel(OutputName, VolLevel)
end

function AVSwitchReport_MuteState(OutputName, MutedFlag)
	TheMixer:SetMuteState(OutputName, MutedFlag)
end

function AVSwitchReport_LoudnessState(OutputName, LoudnessFlag)
	TheMixer:SetLoudnessState(OutputName, LoudnessFlag)
end

function AVSwitchReport_TrebleLevel(OutputName, TrebleLevel)
	TheMixer:SetTrebleLevel(OutputName, TrebleLevel)
end

function AVSwitchReport_BassLevel(OutputName, BassLevel)
	TheMixer:SetBassLevel(OutputName, BassLevel)
end

function AVSwitchReport_BalanceLevel(OutputName, BalanceLevel)
	TheMixer:SetBalanceLevel(OutputName, BalanceLevel)
end
]]


