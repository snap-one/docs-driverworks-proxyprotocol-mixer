--[[=============================================================================
    File is: avswitch_apis.lua

    Copyright Snap One, LLC. All Rights Reserved.
	
	API calls for developers using avswitch template code
===============================================================================]]

-- This macro is utilized to identify the version string of the driver template version used.
if (TEMPLATE_VERSION ~= nil) then
	TEMPLATE_VERSION.avswitch_apis = "2025.03.11"
end

--==================================================================

--[[
function GetCurrentVolume(OutputName)
	return TheMixer:GetCurrentVolume(OutputName)
end

function IsMuted(OutputName)
	return TheMixer:IsMuted(OutputName)
end

function IsLoudnessOn(OutputName)
	return TheMixer:IsLoudnessOn(OutputName)
end

function GetCurrentTrebleLevel(OutputName)
	return TheMixer:GetCurrentTrebleLevel(OutputName)
end

function GetCurrentBassLevel(OutputName)
	return TheMixer:GetCurrentBassLevel(OutputName)
end

function GetCurrentBalanceLevel(OutputName)
	return TheMixer:GetCurrentBalanceLevel(OutputName)
end
]]
